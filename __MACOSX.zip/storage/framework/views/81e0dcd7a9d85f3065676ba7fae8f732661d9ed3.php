<?php $__env->startSection('settings_title',trans('lang.custom_field_table')); ?>
<?php $__env->startSection('settings_content'); ?>
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card shadow-sm">
        <div class="card-header">
            <ul class="nav nav-tabs d-flex flex-md-row flex-column-reverse align-items-start card-header-tabs">
                <div class="d-flex flex-row">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo url()->current(); ?>"><i class="fas fa-list mr-2"></i><?php echo e(trans('lang.custom_field_table')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo route('customFields.create'); ?>"><i class="fas fa-plus mr-2"></i><?php echo e(trans('lang.custom_field_create')); ?>

                        </a>
                    </li>
                </div>
                <?php echo $__env->make('layouts.right_toolbar', compact('dataTable'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </ul>
        </div>
        <div class="card-body">
            <?php echo $__env->make('settings.custom_fields.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="clearfix"></div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.settings.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/solicitous/public_html/h2o/resources/views/settings/custom_fields/index.blade.php ENDPATH**/ ?>