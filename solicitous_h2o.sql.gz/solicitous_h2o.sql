-- MySQL dump 10.13  Distrib 5.7.37, for Linux (x86_64)
--
-- Host: localhost    Database: solicitous_h2o
-- ------------------------------------------------------
-- Server version	5.7.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` double(20,17) NOT NULL DEFAULT '0.00000000000000000',
  `longitude` double(20,17) NOT NULL DEFAULT '0.00000000000000000',
  `default` tinyint(1) DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_user_id_foreign` (`user_id`),
  CONSTRAINT `addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` (`id`, `description`, `address`, `latitude`, `longitude`, `default`, `user_id`, `created_at`, `updated_at`) VALUES (1,'Workshop','829 Athena Track\nNorth Maryjane, AL 19240-3641',50.41204544000000000,9.30321229000000000,0,8,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(2,'Building','5772 Leo Lodge\nWest Keegan, ID 85009',51.35350437000000000,9.85855358000000000,0,6,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(3,'Work','6176 Lorna Wells\nHackettfurt, CO 18466-6205',51.07229912000000000,11.87392271000000000,0,2,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(4,'Home','22307 Leilani Ridge Apt. 962\nBoyerfort, WV 09413-3817',51.55610331000000000,11.40972093000000000,0,1,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(5,'Work','284 Senger Rue\nPort Icieborough, LA 60476-1246',50.58783021000000000,9.95358447000000000,0,4,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(6,'Hotel','324 Herzog Ford\nSawaynfort, MN 17396',51.63328182000000000,9.68677941000000000,0,7,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(7,'Home','9699 Padberg Orchard\nAntoninaland, IA 23433-6778',51.74320000000000000,10.49388110000000000,0,3,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(8,'Workshop','919 Bailey Turnpike\nToyburgh, NE 33446',50.14558319000000000,10.91163583000000000,0,3,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(9,'Home','3123 Elliott Harbor Suite 172\nPort Idell, NE 54593',50.82555793000000000,9.98740505000000000,0,1,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(10,'Building','441 Rubye Plaza Apt. 615\nNorth Glenna, IA 22922-0310',50.77702805000000000,11.25195799000000000,0,7,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(11,'Work','129 Grimes Flats\nRicestad, TN 93156',51.96166988000000000,10.53869743000000000,0,4,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(12,'Building','146 Laury Village\nHettingerport, AK 34608',51.94032846000000000,9.68907893000000000,0,8,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(13,'Workshop','402 Guido Turnpike\nColinside, HI 24657-5314',51.61930047000000000,11.08578449000000000,0,3,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(14,'Office','801 Bruen Fort\nAntoniettaburgh, SC 88890-9131',50.18472779000000000,9.73278628000000000,0,3,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(15,'Building','252 Declan Lake Apt. 156\nNew Francisca, AZ 46319',50.01913925000000000,9.64384659000000000,0,6,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(16,'Workshop','496 Heaney Lane\nNew Frida, AL 83069',50.47463228000000000,9.12534150000000000,0,1,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(17,'Home','9922 Marilou Haven\nNolanmouth, GA 90999',51.86004428000000000,10.80225213000000000,0,4,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(18,'Building','2134 Winona Knolls\nSouth Sydniefort, NH 05655-1431',50.97614997000000000,9.34338259000000000,0,7,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(19,'Home','694 Hobart Shoal\nAlexandrahaven, AL 20623',50.25055406000000000,11.12742561000000000,0,7,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(20,'Building','218 Megane Curve\nPablotown, OH 53334',51.69334827000000000,11.25910112000000000,0,7,'2022-05-17 07:26:20','2022-05-17 07:26:20');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_settings_key_index` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
INSERT INTO `app_settings` (`id`, `key`, `value`) VALUES (7,'date_format','l jS F Y (H:i:s)'),(8,'language','en'),(17,'is_human_date_format','1'),(18,'app_name','H2O'),(19,'app_short_description','Hire Equals Opportunity'),(20,'mail_driver','smtp'),(21,'mail_host','smtp.hostinger.com'),(22,'mail_port','587'),(23,'mail_username','test@demo.com'),(24,'mail_password','-'),(25,'mail_encryption','ssl'),(26,'mail_from_address','test@demo.com'),(27,'mail_from_name','Smarter Vision'),(30,'timezone','Indian/Antananarivo'),(32,'theme_contrast','light'),(33,'theme_color','primary'),(34,'app_logo','ff07391a-88f7-4f58-aa9f-f738057c46db'),(35,'nav_color','navbar-dark navbar-navy'),(38,'logo_bg_color','text-light  navbar-navy'),(66,'default_role','admin'),(68,'facebook_app_id','518416208939727'),(69,'facebook_app_secret','93649810f78fa9ca0d48972fee2a75cd'),(71,'twitter_app_id','twitter'),(72,'twitter_app_secret','twitter 1'),(74,'google_app_id','527129559488-roolg8aq110p8r1q952fqa9tm06gbloe.apps.googleusercontent.com'),(75,'google_app_secret','FpIi8SLgc69ZWodk-xHaOrxn'),(77,'enable_google','1'),(78,'enable_facebook','1'),(93,'enable_stripe','1'),(94,'stripe_key','pk_test_pltzOnX3zsUZMoTTTVUL4O41'),(95,'stripe_secret','sk_test_o98VZx3RKDUytaokX4My3a20'),(101,'custom_field_models.0','App\\Models\\User'),(104,'default_tax','10'),(107,'default_currency','₹'),(108,'fixed_header','1'),(109,'fixed_footer','0'),(110,'fcm_key','AAAAHMZiAQA:APA91bEb71b5sN5jl-w_mmt6vLfgGY5-_CQFxMQsVEfcwO3FAh4-mk1dM6siZwwR3Ls9U0pRDpm96WN1AmrMHQ906GxljILqgU2ZB6Y1TjiLyAiIUETpu7pQFyicER8KLvM9JUiXcfWK'),(111,'enable_notifications','1'),(112,'paypal_username','sb-z3gdq482047_api1.business.example.com'),(113,'paypal_password','-'),(114,'paypal_secret','-'),(115,'enable_paypal','1'),(116,'main_color','#072053'),(117,'main_dark_color','#072053'),(118,'second_color','#08143A'),(119,'second_dark_color','#CCCCDD'),(120,'accent_color','#8C9DA8'),(121,'accent_dark_color','#9999AA'),(122,'scaffold_dark_color','#2C2C2C'),(123,'scaffold_color','#FAFAFA'),(124,'google_maps_key','1'),(125,'mobile_language','en'),(126,'app_version','1.0.0'),(127,'enable_version','1'),(128,'default_currency_id','3'),(129,'default_currency_code','INR'),(130,'default_currency_decimal_digits','2'),(131,'default_currency_rounding','0'),(132,'currency_right','1'),(133,'distance_unit','km'),(134,'default_theme','light'),(135,'enable_paystack','1'),(136,'paystack_key','pk_test_d754715fa3fa9048c9ab2832c440fb183d7c91f5'),(137,'paystack_secret','sk_test_66f87edaac94f8adcb28fdf7452f12ccc63d068d'),(138,'enable_flutterwave','1'),(139,'flutterwave_key','FLWPUBK_TEST-d465ba7e4f6b86325cb9881835726402-X'),(140,'flutterwave_secret','FLWSECK_TEST-d3f8801da31fc093fb1207ea34e68fbb-X'),(141,'enable_stripe_fpx','1'),(142,'stripe_fpx_key','pk_test_51IQ0zvB0wbAJesyPLo3x4LRgOjM65IkoO5hZLHOMsnO2RaF0NlH7HNOfpCkjuLSohvdAp30U5P1wKeH98KnwXkOD00mMDavaFX'),(143,'stripe_fpx_secret','sk_test_51IQ0zvB0wbAJesyPUtR7yGdyOR7aGbMQAX5Es9P56EDUEsvEQAC0NBj7JPqFuJEYXrvSCm5OPRmGaUQBswjkRxVB00mz8xhkFX'),(144,'enable_paymongo','1'),(145,'paymongo_key','pk_test_iD6aYYm4yFuvkuisyU2PGSYH'),(146,'paymongo_secret','sk_test_oxD79bMKxb8sA47ZNyYPXwf3'),(147,'provider_app_name','Service Provider'),(148,'default_country_code','IN');
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `availability_hours`
--

DROP TABLE IF EXISTS `availability_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `availability_hours` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `day` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monday',
  `start_at` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_at` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci,
  `e_provider_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `availability_hours_e_provider_id_foreign` (`e_provider_id`),
  CONSTRAINT `availability_hours_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `availability_hours`
--

LOCK TABLES `availability_hours` WRITE;
/*!40000 ALTER TABLE `availability_hours` DISABLE KEYS */;
INSERT INTO `availability_hours` (`id`, `day`, `start_at`, `end_at`, `data`, `e_provider_id`) VALUES (1,'monday','04:00','15:00','{\"en\":\"Rerum quo odio soluta ipsum dolor illo.\"}',5),(2,'tuesday','05:00','15:00','{\"en\":\"Voluptas in in dolores ipsa nemo neque dolore.\"}',5),(3,'sunday','10:00','21:00','{\"en\":\"Consequuntur assumenda omnis qui laborum iusto.\"}',16),(4,'monday','10:00','21:00','{\"en\":\"Impedit id et et suscipit vel ipsa quae.\"}',1),(5,'monday','03:00','18:00','{\"en\":\"Et nam dolore ut sed quis. Sit nihil et suscipit.\"}',16),(6,'saturday','11:00','17:00','{\"en\":\"Optio reiciendis nobis nam est cupiditate.\"}',3),(7,'sunday','11:00','18:00','{\"en\":\"Nam deserunt soluta non iure.\"}',9),(8,'wednesday','10:00','15:00','{\"en\":\"Velit magnam autem dicta cum et.\"}',9),(9,'wednesday','02:00','18:00','{\"en\":\"Repellat eveniet et nisi accusamus odit aut.\"}',4),(10,'wednesday','11:00','22:00','{\"en\":\"Magni repellat non unde iusto.\"}',4),(11,'thursday','02:00','20:00','{\"en\":\"Saepe magnam iure veniam beatae.\"}',11),(12,'wednesday','10:00','23:00','{\"en\":\"Voluptatem et dolor alias et sed dolores rerum.\"}',9),(13,'friday','03:00','14:00','{\"en\":\"At qui quidem quo et sed.\"}',13),(14,'sunday','02:00','23:00','{\"en\":\"Eum commodi error magni magnam repellat sed.\"}',18),(15,'wednesday','04:00','21:00','{\"en\":\"Ad velit facilis earum quod reiciendis nostrum.\"}',12),(16,'friday','02:00','16:00','{\"en\":\"Distinctio voluptatum sunt et cum aut ut optio.\"}',10),(17,'thursday','02:00','23:00','{\"en\":\"Modi sunt nisi mollitia atque.\"}',7),(18,'sunday','10:00','14:00','{\"en\":\"Deserunt animi ut repellendus optio.\"}',11),(19,'sunday','08:00','20:00','{\"en\":\"Ipsam quas facilis esse deserunt.\"}',11),(20,'sunday','02:00','14:00','{\"en\":\"Voluptas in facilis enim molestias et maxime.\"}',13),(21,'tuesday','12:00','21:00','{\"en\":\"Est id aliquam earum debitis reiciendis est odit.\"}',17),(22,'saturday','10:00','21:00','{\"en\":\"Non commodi reiciendis porro voluptatem et.\"}',10),(23,'tuesday','04:00','13:00','{\"en\":\"Inventore quam non ea.\"}',8),(24,'sunday','12:00','13:00','{\"en\":\"Et molestias quo esse vitae et.\"}',15),(25,'thursday','05:00','23:00','{\"en\":\"Est voluptatum aspernatur ab rem facilis.\"}',8),(26,'friday','03:00','13:00','{\"en\":\"Nihil in sequi numquam quo voluptas recusandae.\"}',7),(27,'saturday','07:00','20:00','{\"en\":\"Et ut nihil nisi ut reiciendis repellat aut eos.\"}',9),(28,'thursday','10:00','16:00','{\"en\":\"Saepe qui aliquid sint quo ex inventore autem.\"}',14),(29,'tuesday','09:00','15:00','{\"en\":\"Sit numquam est aut animi assumenda eos.\"}',2),(30,'saturday','07:00','19:00','{\"en\":\"Dolores sit veritatis fuga officia ratione aut.\"}',16),(31,'sunday','07:00','18:00','{\"en\":\"Amet temporibus at dolor blanditiis.\"}',15),(32,'thursday','02:00','20:00','{\"en\":\"Id suscipit nihil eius et voluptatibus.\"}',6),(33,'friday','08:00','13:00','{\"en\":\"Repellat dolor illo in quia quisquam voluptas.\"}',18),(34,'friday','02:00','19:00','{\"en\":\"Et tenetur ut qui iure ut.\"}',18),(35,'thursday','07:00','23:00','{\"en\":\"Quam sed aut in quis quis.\"}',11),(36,'friday','04:00','13:00','{\"en\":\"Non distinctio ratione dignissimos eos.\"}',18),(37,'saturday','11:00','13:00','{\"en\":\"Sapiente officiis doloribus voluptatum.\"}',17),(38,'friday','04:00','22:00','{\"en\":\"Qui libero soluta sed qui corporis quis.\"}',8),(39,'monday','05:00','21:00','{\"en\":\"Reprehenderit atque dignissimos quam ipsam quae.\"}',18),(40,'monday','02:00','17:00','{\"en\":\"Ab quia labore aut maiores velit.\"}',10),(41,'saturday','06:00','19:00','{\"en\":\"A magnam in beatae enim consectetur ut expedita.\"}',12),(42,'saturday','03:00','20:00','{\"en\":\"Impedit sequi id id.\"}',13),(43,'wednesday','03:00','20:00','{\"en\":\"Tempora et quae velit nemo ipsa.\"}',8),(44,'tuesday','04:00','16:00','{\"en\":\"Reprehenderit aut ullam placeat.\"}',18),(45,'friday','06:00','21:00','{\"en\":\"Consequatur mollitia facere aut omnis quis.\"}',4),(46,'saturday','06:00','15:00','{\"en\":\"Et cupiditate sed in quia.\"}',3),(47,'saturday','10:00','16:00','{\"en\":\"Vitae reiciendis eos dolores molestiae vitae.\"}',13),(48,'thursday','06:00','18:00','{\"en\":\"Aut et dolor ut non sed doloribus.\"}',14),(49,'friday','07:00','16:00','{\"en\":\"Impedit quia commodi odit.\"}',17),(50,'friday','07:00','18:00','{\"en\":\"Quidem vel et quia doloribus quo.\"}',13);
/*!40000 ALTER TABLE `availability_hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `awards`
--

DROP TABLE IF EXISTS `awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `awards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext COLLATE utf8mb4_unicode_ci,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `e_provider_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `awards_e_provider_id_foreign` (`e_provider_id`),
  CONSTRAINT `awards_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `awards`
--

LOCK TABLES `awards` WRITE;
/*!40000 ALTER TABLE `awards` DISABLE KEYS */;
INSERT INTO `awards` (`id`, `title`, `description`, `e_provider_id`, `created_at`, `updated_at`) VALUES (1,'{\"en\":\"Sequi id voluptas fugiat qui cumque. Nisi vitae ut qui ut nisi et ipsam.\"}','{\"en\":\"I hadn\'t gone down that rabbit-hole--and yet--and yet--it\'s rather curious, you know, and he called the Queen, but she could not possibly reach it: she could see, when she heard a little pattering.\"}',6,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(2,'{\"en\":\"Molestiae ullam velit maiores neque. Qui cupiditate magnam perspiciatis assumenda amet architecto.\"}','{\"en\":\"Rabbit hastily interrupted. \'There\'s a great letter, nearly as she spoke. (The unfortunate little Bill had left off writing on his spectacles and looked anxiously round, to make SOME change in my.\"}',10,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(3,'{\"en\":\"Veritatis sit saepe error rerum. Soluta ut ducimus quisquam vel. Aut error modi eum neque.\"}','{\"en\":\"COULD grin.\' \'They all can,\' said the Mock Turtle, suddenly dropping his voice; and Alice guessed who it was, even before she had wept when she was going on, as she could not swim. He sent them word.\"}',9,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(4,'{\"en\":\"Eum sit id laudantium ut voluptates quis. Nemo est aut explicabo quasi. Vero sit est quo et.\"}','{\"en\":\"OF ITS WAISTCOAT-POCKET, and looked very uncomfortable. The moment Alice appeared, she was playing against herself, for she was out of the sort,\' said the Mouse to tell you--all I know I do!\' said.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(5,'{\"en\":\"Quos similique ipsum facilis illo voluptate magnam. Et ullam distinctio mollitia iusto.\"}','{\"en\":\"Suppress him! Pinch him! Off with his whiskers!\' For some minutes it seemed quite natural to Alice again. \'No, I didn\'t,\' said Alice: \'I don\'t see how he did with the distant sobs of the other side.\"}',5,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(6,'{\"en\":\"Est autem tempore deserunt. Aut fugit veniam dolorem. Cum id accusamus quas nostrum.\"}','{\"en\":\"She was close behind her, listening: so she set to work, and very nearly carried it off. * * * * * * * * * \'What a funny watch!\' she remarked. \'It tells the day of the ground, Alice soon came to the.\"}',14,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(7,'{\"en\":\"Aut velit aut ullam ut tenetur fuga. Labore incidunt sit ut debitis aliquid voluptatem.\"}','{\"en\":\"WOULD go with the grin, which remained some time busily writing in his throat,\' said the Hatter. This piece of evidence we\'ve heard yet,\' said the King, \'that only makes the world she was quite.\"}',11,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(8,'{\"en\":\"Est et laboriosam non eaque. Distinctio reprehenderit dolore ut dolores.\"}','{\"en\":\"Mock Turtle, \'but if you\'ve seen them so often, of course had to be in a melancholy way, being quite unable to move. She soon got it out loud. \'Thinking again?\' the Duchess was VERY ugly; and.\"}',6,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(9,'{\"en\":\"Reprehenderit velit nihil ea reprehenderit ut velit. Impedit sit natus et.\"}','{\"en\":\"Gryphon. \'It all came different!\' Alice replied in an offended tone, and added with a great hurry. An enormous puppy was looking at it gloomily: then he dipped it into his cup of tea, and looked at.\"}',10,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(10,'{\"en\":\"Nemo nihil delectus ut aperiam ullam et. Exercitationem id provident et ipsam commodi.\"}','{\"en\":\"Alice in a louder tone. \'ARE you to death.\\\"\' \'You are old,\' said the Dormouse went on, very much confused, \'I don\'t even know what \\\"it\\\" means well enough, when I breathe\\\"!\' \'It IS the fun?\' said.\"}',14,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(11,'{\"en\":\"Porro explicabo distinctio doloribus amet. Sed dolorum ab fugit possimus illum.\"}','{\"en\":\"Footman went on again: \'Twenty-four hours, I THINK; or is it twelve? I--\' \'Oh, don\'t talk about trouble!\' said the King: \'however, it may kiss my hand if it makes rather a handsome pig, I think.\'.\"}',5,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(12,'{\"en\":\"Perspiciatis repellendus vel tempora. Sit velit est odio rerum. Ullam sit ut est in sit.\"}','{\"en\":\"Dormouse shook its head to feel very queer to ME.\' \'You!\' said the Duchess, \'chop off her unfortunate guests to execution--once more the shriek of the court. All this time it vanished quite slowly.\"}',6,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(13,'{\"en\":\"Accusantium quas et tempora quod. Maxime mollitia accusamus aut inventore consequuntur eum nobis.\"}','{\"en\":\"Queen jumped up on to the law, And argued each case with MINE,\' said the Mock Turtle sighed deeply, and began, in a frightened tone. \'The Queen will hear you! You see, she came up to the Queen. \'You.\"}',7,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(14,'{\"en\":\"Tempora enim occaecati corporis. Quae labore est nesciunt iure dolorum.\"}','{\"en\":\"I wonder if I might venture to ask the question?\' said the Caterpillar called after her. \'I\'ve something important to say!\' This sounded promising, certainly: Alice turned and came flying down upon.\"}',6,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(15,'{\"en\":\"Harum non totam quis. Labore repellat magni ut recusandae. Sint voluptatum est fuga accusamus.\"}','{\"en\":\"So they got thrown out to be ashamed of yourself,\' said Alice, very earnestly. \'I\'ve had nothing yet,\' Alice replied in a minute. Alice began in a frightened tone. \'The Queen of Hearts, and I shall.\"}',10,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(16,'{\"en\":\"Qui unde dicta numquam at. Sit cupiditate et omnis atque enim culpa.\"}','{\"en\":\"I\'ll try if I know all the first figure!\' said the Duchess: \'and the moral of that is--\\\"Birds of a good deal worse off than before, as the question was evidently meant for her. \'I can see you\'re.\"}',4,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(17,'{\"en\":\"Odio sit dignissimos dolores quis possimus. Et sunt qui laborum officia unde. Expedita et ut nam.\"}','{\"en\":\"She was a large dish of tarts upon it: they looked so good, that it would be of any use, now,\' thought poor Alice, \'to pretend to be rude, so she began nibbling at the top of her going, though she.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(18,'{\"en\":\"Nulla qui eum et fugit velit suscipit. Quaerat ut a doloribus. Ut aut qui tempore quos suscipit.\"}','{\"en\":\"After these came the guests, mostly Kings and Queens, and among them Alice recognised the White Rabbit returning, splendidly dressed, with a table in the window, she suddenly spread out her hand.\"}',11,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(19,'{\"en\":\"Qui quasi eligendi nobis vitae. Ut natus neque placeat omnis. Et qui natus est cum quis et nisi.\"}','{\"en\":\"But if I\'m Mabel, I\'ll stay down here! It\'ll be no use in waiting by the way, was the first verse,\' said the Duchess, who seemed to listen, the whole window!\' \'Sure, it does, yer honour: but it\'s an.\"}',14,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(20,'{\"en\":\"Rem qui optio in inventore. Odit dolorem beatae qui eos ut qui ut. Ducimus dolorem qui ex ad.\"}','{\"en\":\"I suppose Dinah\'ll be sending me on messages next!\' And she began looking at them with one finger; and the blades of grass, but she had grown up,\' she said to Alice. \'What sort of way to explain the.\"}',13,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(21,'{\"en\":\"Illo possimus nobis porro. Sint quisquam quisquam ea culpa praesentium sit rerum.\"}','{\"en\":\"Hatter replied. \'Of course you know why it\'s called a whiting?\' \'I never went to the company generally, \'You are all pardoned.\' \'Come, THAT\'S a good deal frightened by this time?\' she said to the.\"}',5,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(22,'{\"en\":\"Amet qui atque in magni aut deleniti rerum. Et quis qui sint labore saepe iure molestiae.\"}','{\"en\":\"Mock Turtle: \'crumbs would all wash off in the house, and found herself lying on the slate. \'Herald, read the accusation!\' said the voice. \'Fetch me my gloves this moment!\' Then came a little.\"}',2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(23,'{\"en\":\"Nemo error qui ut sapiente quae tempore. Omnis esse magni harum sequi quos. Qui ab modi fugit et.\"}','{\"en\":\"Alice had learnt several things of this elegant thimble\'; and, when it saw Alice. It looked good-natured, she thought: still it was too late to wish that! She went on for some way of keeping up the.\"}',7,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(24,'{\"en\":\"Ut eius aliquid aliquid aliquam quasi temporibus. Aperiam possimus occaecati rerum repudiandae.\"}','{\"en\":\"Alice: \'she\'s so extremely--\' Just then her head made her draw back in a very truthful child; \'but little girls eat eggs quite as much as she went on, \'that they\'d let Dinah stop in the face. \'I\'ll.\"}',10,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(25,'{\"en\":\"Qui quam id quis dolorem est sed consequatur. Tenetur eligendi est quis quidem.\"}','{\"en\":\"Where CAN I have none, Why, I do wonder what was on the OUTSIDE.\' He unfolded the paper as he spoke, and added \'It isn\'t a letter, written by the hedge!\' then silence, and then Alice put down yet.\"}',15,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(26,'{\"en\":\"Non aut fugiat laborum et eum dicta et. Occaecati accusantium sint et numquam. Sequi et et esse.\"}','{\"en\":\"Alice, that she did it at all,\' said the Cat, and vanished. Alice was beginning to end,\' said the Caterpillar contemptuously. \'Who are YOU?\' Which brought them back again to the general conclusion.\"}',8,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(27,'{\"en\":\"Qui cum eaque perferendis eligendi incidunt eligendi. Voluptatem aut delectus pariatur nihil quis.\"}','{\"en\":\"Mouse, in a bit.\' \'Perhaps it doesn\'t understand English,\' thought Alice; \'only, as it\'s asleep, I suppose Dinah\'ll be sending me on messages next!\' And she tried to look down and saying \\\"Come up.\"}',16,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(28,'{\"en\":\"Ut id necessitatibus dignissimos dolorem qui nemo id. Repellendus illum possimus quia sint ex.\"}','{\"en\":\"Hatter. \'I deny it!\' said the Pigeon went on, looking anxiously round to see if she were looking up into hers--she could hear him sighing as if he wasn\'t going to leave the room, when her eye fell.\"}',18,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(29,'{\"en\":\"Qui eum est velit aut. Inventore mollitia eaque laboriosam amet est aut excepturi.\"}','{\"en\":\"I will tell you his history,\' As they walked off together. Alice laughed so much surprised, that for two reasons. First, because I\'m on the top of his teacup instead of onions.\' Seven flung down his.\"}',9,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(30,'{\"en\":\"Dolorum aperiam quod suscipit quisquam. Omnis repellendus assumenda est minima.\"}','{\"en\":\"March Hare and the words \'EAT ME\' were beautifully marked in currants. \'Well, I\'ll eat it,\' said the Gryphon replied rather impatiently: \'any shrimp could have told you butter wouldn\'t suit the.\"}',15,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(31,'{\"en\":\"Odit aut vel consequuntur corporis. Optio earum qui repudiandae et.\"}','{\"en\":\"I can creep under the table: she opened it, and found that, as nearly as she spoke, but no result seemed to quiver all over their slates; \'but it doesn\'t matter which way you have to turn round on.\"}',13,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(32,'{\"en\":\"Impedit minus qui animi. Consequatur quo ipsum voluptas cumque.\"}','{\"en\":\"Alice had no pictures or conversations in it, and fortunately was just in time to be managed? I suppose you\'ll be telling me next that you couldn\'t cut off a head unless there was no use going back.\"}',3,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(33,'{\"en\":\"Dolore tenetur quo unde. Pariatur quasi et aut ab. Et provident quaerat excepturi earum magni ut.\"}','{\"en\":\"English,\' thought Alice; \'I might as well wait, as she leant against a buttercup to rest herself, and nibbled a little of it?\' said the Duchess, it had entirely disappeared; so the King eagerly, and.\"}',16,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(34,'{\"en\":\"Qui harum dolores facere repellendus consequatur. Commodi perspiciatis ipsum dolores et tempore.\"}','{\"en\":\"I was going to leave it behind?\' She said this she looked back once or twice she had never been so much frightened to say \'I once tasted--\' but checked herself hastily. \'I don\'t like them!\' When the.\"}',4,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(35,'{\"en\":\"Et atque non ut odio dolorum corrupti. Sint similique reiciendis at perspiciatis ut.\"}','{\"en\":\"Queen\'s shrill cries to the Dormouse, not choosing to notice this question, but hurriedly went on, spreading out the proper way of escape, and wondering whether she ought not to lie down upon their.\"}',9,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(36,'{\"en\":\"Autem voluptas laborum molestiae ea nulla. Odio voluptatibus iste tempora odit saepe.\"}','{\"en\":\"Alice whispered, \'that it\'s done by everybody minding their own business,\' the Duchess said in a tone of this rope--Will the roof was thatched with fur. It was opened by another footman in livery.\"}',2,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(37,'{\"en\":\"Quae velit unde iure suscipit quibusdam. Debitis officiis quo provident mollitia non qui.\"}','{\"en\":\"I beat him when he pleases!\' CHORUS. \'Wow! wow! wow!\' While the Panther were sharing a pie--\' [later editions continued as follows When the sands are all dry, he is gay as a last resource, she put.\"}',16,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(38,'{\"en\":\"Recusandae aliquid deserunt et tempora sequi. Occaecati tempora unde aut officia amet at.\"}','{\"en\":\"May it won\'t be raving mad--at least not so mad as it spoke. \'As wet as ever,\' said Alice loudly. \'The idea of the ground--and I should think you can have no idea what to say it any longer than.\"}',14,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(39,'{\"en\":\"Excepturi dolor corrupti voluptatem eaque. Qui non id voluptatibus et cumque amet.\"}','{\"en\":\"Alice replied thoughtfully. \'They have their tails fast in their mouths. So they sat down, and was going to happen next. The first witness was the Cat went on, half to itself, half to herself, as.\"}',8,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(40,'{\"en\":\"Illum deleniti labore sed voluptates. Odio id dolorem ipsa velit. Est non numquam eos.\"}','{\"en\":\"Hatter. This piece of bread-and-butter in the last time she had succeeded in bringing herself down to the Mock Turtle replied, counting off the fire, and at last it unfolded its arms, took the.\"}',6,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(41,'{\"en\":\"Sint vero excepturi est labore sit nostrum ut. Dignissimos consectetur accusamus assumenda.\"}','{\"en\":\"King, and the baby was howling so much at first, the two creatures got so much about a whiting to a mouse, That he met in the other. In the very middle of the guinea-pigs cheered, and was going off.\"}',7,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(42,'{\"en\":\"Voluptas omnis qui laudantium vero omnis aut. Voluptatum delectus est id occaecati incidunt quidem.\"}','{\"en\":\"I? Ah, THAT\'S the great concert given by the hand, it hurried off, without waiting for the accident of the table, half hoping that the reason so many lessons to learn! No, I\'ve made up my mind about.\"}',14,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(43,'{\"en\":\"Optio magni possimus quaerat nostrum fugiat. Sit placeat dolorem ut saepe omnis iste.\"}','{\"en\":\"Exactly as we were. My notion was that you had been broken to pieces. \'Please, then,\' said the Cat; and this was his first speech. \'You should learn not to be an advantage,\' said Alice, surprised at.\"}',9,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(44,'{\"en\":\"Esse voluptas et exercitationem. Voluptatem eos quae quia aut maxime error magnam.\"}','{\"en\":\"Caterpillar. \'I\'m afraid I am, sir,\' said Alice; \'I daresay it\'s a French mouse, come over with William the Conqueror.\' (For, with all their simple sorrows, and find a number of cucumber-frames.\"}',15,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(45,'{\"en\":\"Ut eos esse dolorum et voluptatem harum unde. Laborum odit laudantium aut tempore.\"}','{\"en\":\"That he met in the pictures of him), while the Mock Turtle would be worth the trouble of getting her hands on her face like the three were all ornamented with hearts. Next came the guests, mostly.\"}',9,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(46,'{\"en\":\"Aut sunt qui autem vitae. Id ut ut quisquam. Et voluptatem cum dolor earum eius earum voluptas.\"}','{\"en\":\"An enormous puppy was looking at the Lizard as she tucked it away under her arm, and timidly said \'Consider, my dear: she is only a mouse that had a wink of sleep these three weeks!\' \'I\'m very sorry.\"}',5,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(47,'{\"en\":\"Quas provident voluptatem quia ut quod necessitatibus quaerat. Velit omnis soluta fuga distinctio.\"}','{\"en\":\"I will tell you more than nine feet high, and was a treacle-well.\' \'There\'s no sort of life! I do it again and again.\' \'You are old,\' said the Footman, \'and that for two Pennyworth only of beautiful.\"}',1,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(48,'{\"en\":\"Iusto ullam placeat repellendus. Provident et est repudiandae non ut quam occaecati.\"}','{\"en\":\"I\'ll tell you my adventures--beginning from this side of the table, half hoping she might as well be at school at once.\' However, she got to go down--Here, Bill! the master says you\'re to go on.\"}',2,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(49,'{\"en\":\"Autem dolor aut expedita sunt alias id. Sed qui enim quia quo.\"}','{\"en\":\"Alice opened the door began sneezing all at once. \'Give your evidence,\' said the Dormouse, without considering at all comfortable, and it was only too glad to find quite a conversation of it.\"}',11,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(50,'{\"en\":\"Omnis provident earum veritatis laborum ullam minima. Est porro debitis facere culpa est et quo.\"}','{\"en\":\"Alice\'s side as she spoke. \'I must be growing small again.\' She got up this morning, but I can\'t tell you his history,\' As they walked off together, Alice heard the King eagerly, and he went on, \'if.\"}',12,'2022-05-17 07:26:22','2022-05-17 07:26:22');
/*!40000 ALTER TABLE `awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_statuses`
--

DROP TABLE IF EXISTS `booking_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` longtext COLLATE utf8mb4_unicode_ci,
  `order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_statuses`
--

LOCK TABLES `booking_statuses` WRITE;
/*!40000 ALTER TABLE `booking_statuses` DISABLE KEYS */;
INSERT INTO `booking_statuses` (`id`, `status`, `order`, `created_at`, `updated_at`) VALUES (1,'Received',1,'2021-01-25 13:55:46','2021-01-29 12:26:35'),(2,'In Progress',40,'2021-01-25 13:56:02','2021-02-16 16:26:52'),(3,'On the Way',20,'2021-01-28 02:17:23','2021-02-16 06:40:13'),(4,'Accepted',10,'2021-02-16 06:39:29','2021-02-16 06:40:06'),(5,'Ready',30,'2021-02-16 06:41:50','2021-02-16 16:26:42'),(6,'Done',50,'2021-02-16 16:27:02','2021-02-16 16:27:02'),(7,'Failed',60,'2021-02-16 16:28:36','2021-02-16 16:28:36');
/*!40000 ALTER TABLE `booking_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `e_provider` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `e_service` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` longtext COLLATE utf8mb4_unicode_ci,
  `quantity` smallint(6) DEFAULT '1',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `booking_status_id` int(10) unsigned DEFAULT NULL,
  `address` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_id` int(10) unsigned DEFAULT NULL,
  `coupon` longtext COLLATE utf8mb4_unicode_ci,
  `taxes` longtext COLLATE utf8mb4_unicode_ci,
  `booking_at` datetime DEFAULT NULL,
  `start_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `hint` text COLLATE utf8mb4_unicode_ci,
  `cancel` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bookings_user_id_foreign` (`user_id`),
  KEY `bookings_booking_status_id_foreign` (`booking_status_id`),
  KEY `bookings_payment_id_foreign` (`payment_id`),
  CONSTRAINT `bookings_booking_status_id_foreign` FOREIGN KEY (`booking_status_id`) REFERENCES `booking_statuses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `bookings_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `bookings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_ci,
  `color` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `order` int(11) DEFAULT '0',
  `featured` tinyint(1) DEFAULT '0',
  `parent_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_parent_id_foreign` (`parent_id`),
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `color`, `description`, `order`, `featured`, `parent_id`, `created_at`, `updated_at`) VALUES (1,'Car Services','#ff9f43','<p>Categories for all cars services</p>',1,1,NULL,'2021-01-19 11:31:35','2021-01-31 08:49:56'),(2,'Medical Services','#0abde3','<p>Categories for all Medical Services<br></p>',2,1,NULL,'2021-01-19 12:35:00','2021-01-31 08:05:11'),(3,'Laundry Service','#ee5253','<p>Category for all Laundry Service</p>',3,1,NULL,'2021-01-31 08:07:04','2021-02-01 19:03:10'),(4,'Beauty & Hair Cuts','#10ac84','<p>Category for Hair Cuts and Barber</p>',4,0,NULL,'2021-01-31 08:08:37','2021-02-23 09:07:09'),(5,'Washing & Cleaning','#5f27cd','<p>Category for&nbsp;Washing &amp; Cleaning&nbsp;</p>',5,0,NULL,'2021-01-31 08:12:02','2021-01-31 08:12:02'),(6,'Media & Photography','#ff9f43','<p>Category for Media & Photography</p>',6,0,NULL,'2021-01-31 08:13:20','2021-01-31 09:25:51'),(7,'Sewer Cleaning','#5f27cd','<p>Category for Sewer Cleaning<br></p>',1,0,5,'2021-01-31 09:16:15','2021-01-31 09:16:30'),(8,'Carpet Cleaning','#5f27cd','<p>Category for Carpet Cleaning<br></p>',2,0,5,'2021-01-31 09:17:23','2021-01-31 09:17:23'),(9,'Wheel Repair','#5f27cd','<p>Category for Wheel Repair<br></p>',1,0,1,'2021-01-31 09:19:40','2021-01-31 09:19:40');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` double(8,2) NOT NULL DEFAULT '0.00',
  `discount_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percent',
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `expires_at` datetime DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupons_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_ci,
  `symbol` longtext COLLATE utf8mb4_unicode_ci,
  `code` longtext COLLATE utf8mb4_unicode_ci,
  `decimal_digits` tinyint(3) unsigned DEFAULT NULL,
  `rounding` tinyint(3) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` (`id`, `name`, `symbol`, `code`, `decimal_digits`, `rounding`, `created_at`, `updated_at`) VALUES (1,'US Dollar','$','USD',2,0,'2020-10-22 10:20:48','2020-10-22 10:20:48'),(2,'Euro','€','EUR',2,0,'2020-10-22 10:21:39','2020-10-22 10:21:39'),(3,'Indian Rupee','টকা','INR',2,0,'2020-10-22 10:22:50','2020-10-22 10:22:50'),(4,'Indonesian Rupiah','Rp','IDR',0,0,'2020-10-22 10:23:22','2020-10-22 10:23:22'),(5,'Brazilian Real','R$','BRL',2,0,'2020-10-22 10:24:00','2020-10-22 10:24:00'),(6,'Cambodian Riel','៛','KHR',2,0,'2020-10-22 10:25:51','2020-10-22 10:25:51'),(7,'Vietnamese Dong','₫','VND',0,0,'2020-10-22 10:26:26','2020-10-22 10:26:26');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_field_values`
--

DROP TABLE IF EXISTS `custom_field_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  `view` longtext COLLATE utf8mb4_unicode_ci,
  `custom_field_id` int(10) unsigned NOT NULL,
  `customizable_type` varchar(127) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customizable_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_field_values_custom_field_id_foreign` (`custom_field_id`),
  CONSTRAINT `custom_field_values_custom_field_id_foreign` FOREIGN KEY (`custom_field_id`) REFERENCES `custom_fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_field_values`
--

LOCK TABLES `custom_field_values` WRITE;
/*!40000 ALTER TABLE `custom_field_values` DISABLE KEYS */;
INSERT INTO `custom_field_values` (`id`, `value`, `view`, `custom_field_id`, `customizable_type`, `customizable_id`, `created_at`, `updated_at`) VALUES (30,'Explicabo. Eum provi.&nbsp;','Explicabo. Eum provi.&nbsp;',5,'App\\Models\\User',2,'2019-09-06 16:22:30','2021-02-02 06:02:57'),(31,'Modi est libero qui','Modi est libero qui',6,'App\\Models\\User',2,'2019-09-06 16:22:30','2021-02-02 06:02:57'),(33,'Consequatur error ip.&nbsp;','Consequatur error ip.&nbsp;',5,'App\\Models\\User',1,'2019-09-06 16:23:58','2021-02-02 06:02:01'),(34,'Qui vero ratione vel','Qui vero ratione vel',6,'App\\Models\\User',1,'2019-09-06 16:23:58','2021-02-02 06:02:01'),(36,'Dolor optio, error e','Dolor optio, error e',5,'App\\Models\\User',3,'2019-10-15 11:51:32','2021-02-02 06:03:23'),(37,'Voluptatibus ad ipsu','Voluptatibus ad ipsu',6,'App\\Models\\User',3,'2019-10-15 11:51:32','2021-02-02 06:03:23'),(39,'Faucibus ornare suspendisse sed nisi lacus sed. Pellentesque sit amet porttitor eget dolor morbi non arcu. Eu scelerisque felis imperdiet proin fermentum leo vel orci porta','Faucibus ornare suspendisse sed nisi lacus sed. Pellentesque sit amet porttitor eget dolor morbi non arcu. Eu scelerisque felis imperdiet proin fermentum leo vel orci porta',5,'App\\Models\\User',4,'2019-10-16 14:01:46','2019-10-16 14:01:46'),(40,'Sequi molestiae ipsa1','Sequi molestiae ipsa1',6,'App\\Models\\User',4,'2019-10-16 14:01:46','2021-02-21 18:02:10'),(42,'Omnis fugiat et cons.','Omnis fugiat et cons.',5,'App\\Models\\User',5,'2019-12-15 13:19:44','2021-02-02 05:59:47'),(43,'Consequatur delenit','Consequatur delenit',6,'App\\Models\\User',5,'2019-12-15 13:19:44','2021-02-02 05:59:47'),(45,'<p>Short bio for this driver</p>','Short bio for this driver',5,'App\\Models\\User',6,'2020-03-29 11:58:05','2020-03-29 11:58:05'),(46,'4722 Villa Drive','4722 Villa Drive',6,'App\\Models\\User',6,'2020-03-29 11:58:05','2020-03-29 11:58:05'),(48,'Voluptatem. Omnis op.','Voluptatem. Omnis op.',5,'App\\Models\\User',7,'2021-01-17 10:43:24','2021-02-02 06:01:36'),(49,'Perspiciatis aut ei','Perspiciatis aut ei',6,'App\\Models\\User',7,'2021-01-17 10:43:24','2021-02-02 06:01:36'),(51,'sdfsdf56','sdfsdf56',5,'App\\Models\\User',8,'2021-02-10 06:01:12','2021-02-19 08:39:37'),(52,'Adressttt','Adressttt',6,'App\\Models\\User',8,'2021-02-10 06:01:12','2021-02-19 08:27:27');
/*!40000 ALTER TABLE `custom_field_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(127) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(56) COLLATE utf8mb4_unicode_ci NOT NULL,
  `values` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disabled` tinyint(1) DEFAULT NULL,
  `required` tinyint(1) DEFAULT NULL,
  `in_table` tinyint(1) DEFAULT NULL,
  `bootstrap_column` tinyint(4) DEFAULT NULL,
  `order` tinyint(4) DEFAULT NULL,
  `custom_field_model` varchar(127) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
INSERT INTO `custom_fields` (`id`, `name`, `type`, `values`, `disabled`, `required`, `in_table`, `bootstrap_column`, `order`, `custom_field_model`, `created_at`, `updated_at`) VALUES (5,'bio','textarea',NULL,0,0,0,6,1,'App\\Models\\User','2019-09-06 16:13:58','2019-09-06 16:13:58'),(6,'address','text',NULL,0,0,0,6,3,'App\\Models\\User','2019-09-06 16:19:22','2019-09-06 16:19:22');
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_pages`
--

DROP TABLE IF EXISTS `custom_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `published` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_pages`
--

LOCK TABLES `custom_pages` WRITE;
/*!40000 ALTER TABLE `custom_pages` DISABLE KEYS */;
INSERT INTO `custom_pages` (`id`, `title`, `content`, `published`, `created_at`, `updated_at`) VALUES (1,'Privacy Policy','<h1>Privacy Policy of SmarterVision</h1>\n<p>SmarterVision operates the SmarterVision website, which provides the SERVICE.</p>\n<p>This page is used to inform website visitors regarding our policies with the collection, use, and disclosure of Personal Information if anyone decided to use our Service, the smartersvision.com website.</p>\n<p>If you choose to use our Service, then you agree to the collection and use of information in relation with this policy. The Personal Information that we collect are used for providing and improving the Service. We will not use or share your information with anyone except as described in this Privacy Policy.</p>\n<p>The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which is accessible at smartersvision.com, unless otherwise defined in this Privacy Policy.</p>\n<h2>Information Collection and Use</h2>\n<p>For a better experience, while using our Service, we may require you to provide us with certain personally identifiable information, including but not limited to your name, phone number, and postal address. The information that we collect will be used to contact or identify you.</p>\n<h2>Log Data</h2>\n<p>We want to inform you that whenever you visit our Service, we collect information that your browser sends to us which is called Log Data. This Log Data may include information such as your computer\'s Internet Protocol (“IP”) address, browser version, pages of our Service that you visit, the time and date of your visit, the time spent on those pages, and other statistics.</p>\n<h2>Cookies</h2>\n<p>Cookies are files with small amount of data that is commonly used an anonymous unique identifier. These are sent to your browser from the website that you visit and are stored on your computer\'s hard drive.</p>\n<p>Our website uses these “cookies” to collection information and to improve our Service. You have the option to either accept or refuse these cookies, and know when a cookie is being sent to your computer. If you choose to refuse our cookies, you may not be able to use some portions of our Service.</p>\n<h2>Service Providers</h2>\n<p>We may employ third-party companies and individuals due to the following reasons:</p>\n<ul>\n<li>To facilitate our Service;</li>\n<li>To provide the Service on our behalf;</li>\n<li>To perform Service-related services; or</li>\n<li>To assist us in analyzing how our Service is used.</li>\n</ul>\n<p>We want to inform our Service users that these third parties have access to your Personal Information. The reason is to perform the tasks assigned to them on our behalf. However, they are obligated not to disclose or use the information for any other purpose.</p>\n<h2>Security</h2>\n<p>We value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and we cannot guarantee its absolute security.</p>\n<h2>Links to Other Sites</h2>\n<p>Our Service may contain links to other sites. If you click on a third-party link, you will be directed to that site. Note that these external sites are not operated by us. Therefore, we strongly advise you to review the Privacy Policy of these websites. We have no control over, and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services.</p>\n<h2>Children\'s Privacy</h2>\n<p>Our Services do not address anyone under the age of 13. We do not knowingly collect personal identifiable information from children under 13. In the case we discover that a child under 13 has provided us with personal information, we immediately delete this from our servers. If you are a parent or guardian and you are aware that your child has provided us with personal information, please contact us so that we will be able to do necessary actions.</p>\n<h2>Changes to This Privacy Policy</h2>\n<p>We may update our Privacy Policy from time to time. Thus, we advise you to review this page periodically for any changes. We will notify you of any changes by posting the new Privacy Policy on this page. These changes are effective immediately, after they are posted on this page.</p>\n<h2>Contact Us</h2>\n<p>If you have any questions or suggestions about our Privacy Policy, do not hesitate to contact us.</p>',1,'2021-02-24 06:23:21','2021-02-24 07:49:19'),(2,'Terms & Conditions','<h2>Terms &amp; Conditions</h2><p>Dolor consequat. Ex ducimus, dolores fugiat ipsam sunt non a dolor quidem nulla ullamco Nam labore nostrum sit amet, tenetur ut consequatur? Non aut incididunt consequatur, rem veniam, veritatis molestiae neque non veniam, nemo facilis eligendi qui aut enim aperiam rerum fugiat, dolorum qui id, in sint et assumenda mollitia dignissimos illum, ipsum maiores asperiores exercitationem odio labore laboris consequatur? Consequatur, sapiente ipsum, laboriosam, laudantium, dolor sed autem eligendi ea a.</p><p>Dolor consequat. Ex ducimus, dolores fugiat ipsam sunt non a dolor quidem nulla ullamco Nam labore nostrum sit amet, tenetur ut consequatur? Non aut incididunt consequatur, rem veniam, veritatis molestiae neque non veniam, nemo facilis eligendi qui aut enim aperiam rerum fugiat, dolorum qui id, in sint et assumenda mollitia dignissimos illum, ipsum maiores asperiores exercitationem odio labore laboris consequatur? Consequatur, sapiente ipsum, laboriosam, laudantium, dolor sed autem eligendi ea a.<br></p>',1,'2021-02-24 07:50:06','2021-02-24 07:53:52');
/*!40000 ALTER TABLE `custom_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discountables`
--

DROP TABLE IF EXISTS `discountables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discountables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` int(10) unsigned NOT NULL,
  `discountable_type` varchar(127) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discountable_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discountables_coupon_id_foreign` (`coupon_id`),
  CONSTRAINT `discountables_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discountables`
--

LOCK TABLES `discountables` WRITE;
/*!40000 ALTER TABLE `discountables` DISABLE KEYS */;
/*!40000 ALTER TABLE `discountables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_provider_addresses`
--

DROP TABLE IF EXISTS `e_provider_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_provider_addresses` (
  `e_provider_id` int(10) unsigned NOT NULL,
  `address_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`e_provider_id`,`address_id`),
  KEY `e_provider_addresses_address_id_foreign` (`address_id`),
  CONSTRAINT `e_provider_addresses_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `e_provider_addresses_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_provider_addresses`
--

LOCK TABLES `e_provider_addresses` WRITE;
/*!40000 ALTER TABLE `e_provider_addresses` DISABLE KEYS */;
INSERT INTO `e_provider_addresses` (`e_provider_id`, `address_id`) VALUES (4,1),(5,1),(7,1),(12,2),(16,2),(17,2),(9,4),(15,4),(7,5),(10,5),(5,8),(15,8),(7,11),(1,12),(14,12),(3,13),(14,13),(17,13),(2,15),(15,20);
/*!40000 ALTER TABLE `e_provider_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_provider_payouts`
--

DROP TABLE IF EXISTS `e_provider_payouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_provider_payouts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `e_provider_id` int(10) unsigned NOT NULL,
  `method` varchar(127) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(10,2) NOT NULL DEFAULT '0.00',
  `paid_date` datetime NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `e_provider_payouts_e_provider_id_foreign` (`e_provider_id`),
  CONSTRAINT `e_provider_payouts_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_provider_payouts`
--

LOCK TABLES `e_provider_payouts` WRITE;
/*!40000 ALTER TABLE `e_provider_payouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `e_provider_payouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_provider_taxes`
--

DROP TABLE IF EXISTS `e_provider_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_provider_taxes` (
  `e_provider_id` int(10) unsigned NOT NULL,
  `tax_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`e_provider_id`,`tax_id`),
  KEY `e_provider_taxes_tax_id_foreign` (`tax_id`),
  CONSTRAINT `e_provider_taxes_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `e_provider_taxes_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_provider_taxes`
--

LOCK TABLES `e_provider_taxes` WRITE;
/*!40000 ALTER TABLE `e_provider_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `e_provider_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_provider_types`
--

DROP TABLE IF EXISTS `e_provider_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_provider_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_ci,
  `commission` double(5,2) NOT NULL DEFAULT '0.00',
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_provider_types`
--

LOCK TABLES `e_provider_types` WRITE;
/*!40000 ALTER TABLE `e_provider_types` DISABLE KEYS */;
INSERT INTO `e_provider_types` (`id`, `name`, `commission`, `disabled`, `created_at`, `updated_at`) VALUES (2,'Company',75.00,0,'2021-01-13 12:35:35','2021-02-01 15:52:19'),(3,'Freelancer',50.00,0,'2021-01-17 13:57:18','2021-02-24 13:27:30');
/*!40000 ALTER TABLE `e_provider_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_provider_users`
--

DROP TABLE IF EXISTS `e_provider_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_provider_users` (
  `user_id` bigint(20) unsigned NOT NULL,
  `e_provider_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`e_provider_id`),
  KEY `e_provider_users_e_provider_id_foreign` (`e_provider_id`),
  CONSTRAINT `e_provider_users_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `e_provider_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_provider_users`
--

LOCK TABLES `e_provider_users` WRITE;
/*!40000 ALTER TABLE `e_provider_users` DISABLE KEYS */;
INSERT INTO `e_provider_users` (`user_id`, `e_provider_id`) VALUES (4,1),(2,2),(2,3),(2,4),(4,9),(2,12),(2,13),(4,13),(4,14),(6,15),(2,16),(6,16),(6,17);
/*!40000 ALTER TABLE `e_provider_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_providers`
--

DROP TABLE IF EXISTS `e_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_providers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_ci,
  `e_provider_type_id` int(10) unsigned NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `phone_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `availability_range` double(9,2) DEFAULT '0.00',
  `available` tinyint(1) DEFAULT '1',
  `featured` tinyint(1) DEFAULT '0',
  `accepted` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `e_providers_e_provider_type_id_foreign` (`e_provider_type_id`),
  CONSTRAINT `e_providers_e_provider_type_id_foreign` FOREIGN KEY (`e_provider_type_id`) REFERENCES `e_provider_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_providers`
--

LOCK TABLES `e_providers` WRITE;
/*!40000 ALTER TABLE `e_providers` DISABLE KEYS */;
INSERT INTO `e_providers` (`id`, `name`, `e_provider_type_id`, `description`, `phone_number`, `mobile_number`, `availability_range`, `available`, `featured`, `accepted`, `created_at`, `updated_at`) VALUES (1,'{\"en\":\"Glass Ziemann Group\"}',3,'{\"en\":\"Facilis beatae eos animi voluptas sit cum et. Ut consectetur quae non tempore soluta labore est.\"}','+1-470-743-6218','425-833-8559',14102.89,1,1,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(2,'{\"en\":\"Sewer Cleaning Lynch-Schmeler\"}',3,'{\"en\":\"Dolor rem iusto quas sint consequatur in. Dolores nisi consequatur quo possimus suscipit. Est ab sed distinctio quod dolorum architecto.\"}','502-382-3262','+1-713-233-1453',12444.92,1,0,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(3,'{\"en\":\"Roofing Jaskolski LLC\"}',3,'{\"en\":\"Excepturi quidem maiores ut totam dignissimos sit. Non voluptatem velit et. Et laborum unde molestias architecto rem qui rerum non. Tempora nostrum delectus atque facilis doloribus.\"}','(903) 628-7282','(435) 235-6929',9380.62,1,0,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(4,'{\"en\":\"Sewer Cleaning Kertzmann PLC\"}',3,'{\"en\":\"Dolorum non perspiciatis est non ullam itaque. Dignissimos aut itaque consequatur ut sint.\"}','+1-863-773-8120','+1-660-997-7214',7062.46,1,1,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(5,'{\"en\":\"Concrete Heaney-Kshlerin\"}',2,'{\"en\":\"Blanditiis et necessitatibus fugit temporibus praesentium voluptas in. Nam et voluptate iste similique dolorem autem molestias nemo. Maxime quo amet unde voluptatem pariatur natus voluptatem quia.\"}','+1.870.451.3207','+1.623.357.3632',14838.77,1,0,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(6,'{\"en\":\"House Kirlin and Sons\"}',3,'{\"en\":\"Doloribus laborum sunt quia ab dolorem quia. Perspiciatis amet quia voluptatum. Enim magnam corrupti quam aut corporis nulla sed. Atque libero libero quia aspernatur quis repellendus quaerat vel.\"}','1-973-970-0076','234-670-5567',14167.11,1,0,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(7,'{\"en\":\"Painting Connelly-Cassin\"}',3,'{\"en\":\"Commodi ab sint unde rerum. Commodi delectus commodi et et mollitia nobis ratione mollitia. Voluptatum ratione veritatis quisquam quia cupiditate.\"}','+1-989-307-7322','+1-734-813-1870',8305.11,1,0,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(8,'{\"en\":\"House Haley-Lockman\"}',2,'{\"en\":\"Quos aspernatur possimus aut sequi velit inventore. Architecto rerum illo omnis amet. Deserunt optio fugit dolores inventore mollitia ipsam temporibus. Quia expedita est harum delectus.\"}','+1.458.872.4691','+1.830.548.9473',9153.15,1,1,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(9,'{\"en\":\"Glass Beahan, Collier and Bruen\"}',2,'{\"en\":\"Iste enim in rem pariatur doloribus dolores. Qui quasi asperiores aut soluta. Velit molestiae repellat quis quisquam voluptates quod.\"}','586.866.2584','+18202498349',9262.22,1,0,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(10,'{\"en\":\"House Bergstrom PLC\"}',2,'{\"en\":\"Illum libero nulla vitae ratione sit enim quis. Ratione veniam temporibus earum sint dolores autem. Odio incidunt enim odit. Mollitia qui necessitatibus ut at eligendi id et qui.\"}','+1-424-259-9994','(405) 375-5321',7634.58,1,1,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(11,'{\"en\":\"Roofing Hirthe, Davis and Windler\"}',3,'{\"en\":\"Aperiam non omnis ipsum libero omnis. Et dolor enim voluptates placeat iusto quia dolor. Ab necessitatibus voluptatem est facilis. Accusamus voluptate voluptatibus voluptatum laudantium ut autem qui.\"}','(747) 699-0981','1-681-806-2534',9604.90,1,1,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(12,'{\"en\":\"Security Collins Inc\"}',3,'{\"en\":\"Dolorem animi et impedit enim harum. Qui dignissimos quis commodi voluptas possimus et modi et.\"}','779-796-3393','1-636-478-8846',12807.52,1,1,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(13,'{\"en\":\"House Little LLC\"}',2,'{\"en\":\"Quas repellat ut et aut atque et et. Incidunt optio dolor ut repellendus corrupti fuga. Dolor dolorum quisquam tenetur aut. Sit atque molestiae iste ratione nihil.\"}','1-430-682-6389','1-931-375-5734',8100.19,1,0,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(14,'{\"en\":\"Gardner Construction Hoeger-Hill\"}',3,'{\"en\":\"Commodi debitis iste deserunt incidunt voluptatem provident. Quasi quas molestiae placeat. Numquam ut omnis hic. Repellat soluta placeat consectetur et eligendi sit. Pariatur laborum cumque quia.\"}','508.886.2569','(434) 948-8383',13327.87,0,1,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(15,'{\"en\":\"Glass Wiegand-Blick\"}',2,'{\"en\":\"Repudiandae suscipit dolore ut totam. Aut voluptatibus quod ex blanditiis nemo magni molestiae. Aliquam vitae dolor ut iusto est.\"}','+1-347-424-9882','(336) 568-2175',7762.66,1,0,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(16,'{\"en\":\"Security Ratke, Ledner and Johns\"}',2,'{\"en\":\"Sint fuga officiis animi magni minima. Praesentium vitae delectus enim culpa.\"}','(620) 718-7945','(435) 858-4793',6216.03,1,1,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(17,'{\"en\":\"Dentists Torphy, Fahey and Welch\"}',3,'{\"en\":\"Quia nihil similique voluptatem sunt fuga qui nostrum. Ut soluta dignissimos similique beatae. Natus praesentium consequuntur quasi reiciendis dolor.\"}','(918) 803-0137','(260) 891-1878',6549.44,1,1,1,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(18,'{\"en\":\"House Bailey, Windler and O\'Reilly\"}',3,'{\"en\":\"Nihil natus nemo laboriosam explicabo pariatur. Rem sit accusamus est dolor numquam minus. Suscipit doloremque temporibus laudantium ipsam. At nam reiciendis eligendi iusto tempore.\"}','+1-850-370-2570','+1.270.712.9871',7663.65,1,0,1,'2022-05-17 07:26:17','2022-05-17 07:26:17');
/*!40000 ALTER TABLE `e_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_service_categories`
--

DROP TABLE IF EXISTS `e_service_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_service_categories` (
  `e_service_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`e_service_id`,`category_id`),
  KEY `e_service_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `e_service_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `e_service_categories_e_service_id_foreign` FOREIGN KEY (`e_service_id`) REFERENCES `e_services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_service_categories`
--

LOCK TABLES `e_service_categories` WRITE;
/*!40000 ALTER TABLE `e_service_categories` DISABLE KEYS */;
INSERT INTO `e_service_categories` (`e_service_id`, `category_id`) VALUES (5,1),(12,1),(16,1),(18,1),(8,2),(12,2),(15,2),(17,2),(8,4),(10,4),(5,5),(14,5),(16,5),(6,6),(8,6),(14,6),(1,7),(5,7),(9,7),(13,7),(14,7),(13,8),(16,8),(15,9);
/*!40000 ALTER TABLE `e_service_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_service_reviews`
--

DROP TABLE IF EXISTS `e_service_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_service_reviews` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `review` text COLLATE utf8mb4_unicode_ci,
  `rate` decimal(3,2) NOT NULL DEFAULT '0.00',
  `user_id` bigint(20) unsigned NOT NULL,
  `e_service_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `e_service_reviews_user_id_foreign` (`user_id`),
  KEY `e_service_reviews_e_service_id_foreign` (`e_service_id`),
  CONSTRAINT `e_service_reviews_e_service_id_foreign` FOREIGN KEY (`e_service_id`) REFERENCES `e_services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `e_service_reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_service_reviews`
--

LOCK TABLES `e_service_reviews` WRITE;
/*!40000 ALTER TABLE `e_service_reviews` DISABLE KEYS */;
INSERT INTO `e_service_reviews` (`id`, `review`, `rate`, `user_id`, `e_service_id`, `created_at`, `updated_at`) VALUES (1,'I must, I must,\' the King repeated angrily, \'or I\'ll have you got in as well,\' the Hatter.',1.00,8,32,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(2,'Gryphon. \'They can\'t have anything to say, she simply bowed, and took the opportunity of adding.',5.00,7,24,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(3,'Do you think I can find out the answer to it?\' said the Mock Turtle, \'Drive on, old fellow! Don\'t.',5.00,5,11,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(4,'Five, \'and I\'ll tell him--it was for bringing the cook took the thimble, saying \'We beg your.',2.00,5,6,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(5,'Mouse to Alice to herself. Imagine her surprise, when the race was over. However, when they liked.',4.00,8,12,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(6,'Alice, and tried to open her mouth; but she saw maps and pictures hung upon pegs. She took down a.',5.00,5,30,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(7,'They all returned from him to you, Though they were mine before. If I or she should meet the real.',1.00,8,37,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(8,'Five and Seven said nothing, but looked at the door as you might do very well as she listened, or.',1.00,7,28,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(9,'Lizard in head downwards, and the Queen\'s hedgehog just now, only it ran away when it grunted.',4.00,5,37,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(10,'Latin Grammar, \'A mouse--of a mouse--to a mouse--a mouse--O mouse!\') The Mouse only shook its head.',1.00,5,16,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(11,'Alice caught the baby at her feet as the doubled-up soldiers were silent, and looked very.',2.00,3,21,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(12,'For he can thoroughly enjoy The pepper when he sneezes; For he can thoroughly enjoy The pepper.',5.00,5,31,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(13,'I wonder?\' As she said these words her foot as far down the hall. After a time she went round the.',3.00,3,31,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(14,'Pigeon; \'but if you\'ve seen them so often, you know.\' \'I don\'t think--\' \'Then you should say what.',3.00,5,5,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(15,'I think you\'d better finish the story for yourself.\' \'No, please go on!\' Alice said very politely.',1.00,3,1,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(16,'ONE respectable person!\' Soon her eye fell on a branch of a candle is blown out, for she thought.',5.00,8,3,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(17,'In another minute the whole head appeared, and then the other, looking uneasily at the White.',5.00,3,12,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(18,'Hatter continued, \'in this way:-- \"Up above the world go round!\"\' \'Somebody said,\' Alice.',2.00,8,29,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(19,'Rabbit asked. \'No, I didn\'t,\' said Alice: \'besides, that\'s not a regular rule: you invented it.',4.00,5,12,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(20,'Alice, who felt very glad she had finished, her sister on the bank, with her head!\' Alice glanced.',4.00,8,23,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(21,'That\'s all.\' \'Thank you,\' said the Dormouse; \'--well in.\' This answer so confused poor Alice, that.',4.00,7,10,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(22,'But the insolence of his head. But at any rate, the Dormouse fell asleep instantly, and neither of.',5.00,8,10,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(23,'Ugh, Serpent!\' \'But I\'m NOT a serpent, I tell you!\' But she waited patiently. \'Once,\' said the.',1.00,7,7,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(24,'King hastily said, and went on planning to herself as she could not think of anything to say, she.',4.00,5,4,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(25,'His voice has a timid voice at her as hard as it went, as if he were trying to find my way into.',2.00,7,28,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(26,'The Gryphon sat up and walking off to other parts of the shelves as she went on, \'you throw the--\'.',2.00,3,26,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(27,'There seemed to be nothing but the Hatter and the poor little juror (it was exactly three inches.',4.00,5,17,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(28,'The Mock Turtle would be very likely it can talk: at any rate he might answer questions.--How am I.',3.00,7,7,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(29,'Alice. \'You are,\' said the King, rubbing his hands; \'so now let the Dormouse began in a sulky.',4.00,5,24,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(30,'Duchess, digging her sharp little chin. \'I\'ve a right to think,\' said Alice indignantly. \'Let me.',4.00,8,1,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(31,'Dormouse, who was talking. Alice could hardly hear the rattle of the right-hand bit to try the.',2.00,5,29,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(32,'Caterpillar. \'Not QUITE right, I\'m afraid,\' said Alice, as she passed; it was very deep, or she.',1.00,3,15,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(33,'Mouse, who seemed too much overcome to do such a thing as a boon, Was kindly permitted to pocket.',4.00,5,40,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(34,'Alice; \'I daresay it\'s a set of verses.\' \'Are they in the distance. \'And yet what a dear quiet.',4.00,3,18,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(35,'The Gryphon lifted up both its paws in surprise. \'What! Never heard of one,\' said Alice. \'Exactly.',3.00,7,2,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(36,'Why, it fills the whole pack of cards!\' At this the whole court was in the pool of tears which she.',1.00,5,15,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(37,'Jack-in-the-box, and up I goes like a stalk out of breath, and said to live. \'I\'ve seen a rabbit.',4.00,5,34,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(38,'How funny it\'ll seem, sending presents to one\'s own feet! And how odd the directions will look!.',5.00,3,30,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(39,'Pigeon had finished. \'As if I must, I must,\' the King sharply. \'Do you know about it, and very.',5.00,8,15,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(40,'Queen, and in despair she put them into a large canvas bag, which tied up at the top of it. She.',5.00,8,19,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(41,'Alice. \'Then it doesn\'t understand English,\' thought Alice; \'I can\'t explain it,\' said Alice, a.',3.00,8,34,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(42,'Duchess\'s knee, while plates and dishes crashed around it--once more the pig-baby was sneezing on.',2.00,7,7,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(43,'Wonderland of long ago: and how she would have appeared to them to sell,\' the Hatter replied. \'Of.',2.00,5,34,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(44,'Mock Turtle drew a long tail, certainly,\' said Alice in a tone of great dismay, and began staring.',3.00,3,20,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(45,'I\'m quite tired and out of a well?\' \'Take some more tea,\' the Hatter instead!\' CHAPTER VII. A Mad.',1.00,3,21,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(46,'Bill,\' thought Alice,) \'Well, I shan\'t grow any more--As it is, I can\'t see you?\' She was walking.',5.00,7,4,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(47,'King. \'When did you ever eat a bat?\' when suddenly, thump! thump! down she came suddenly upon an.',4.00,7,34,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(48,'I should think very likely to eat or drink anything; so I\'ll just see what the flame of a sea of.',3.00,7,21,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(49,'YOUR temper!\' \'Hold your tongue, Ma!\' said the Cat. \'I\'d nearly forgotten that I\'ve got back to my.',4.00,7,25,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(50,'I almost think I could, if I like being that person, I\'ll come up: if not, I\'ll stay down here!.',1.00,7,34,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(51,'VERY good opportunity for repeating his remark, with variations. \'I shall do nothing of the.',2.00,8,14,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(52,'She pitied him deeply. \'What is his sorrow?\' she asked the Gryphon, \'she wants for to know when.',2.00,7,6,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(53,'White Rabbit, jumping up and walking off to trouble myself about you: you must manage the best cat.',3.00,5,40,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(54,'Pigeon, raising its voice to its feet, \'I move that the hedgehog a blow with its head, it WOULD.',4.00,7,4,'2022-05-17 07:26:19','2022-05-17 07:26:19'),(55,'How brave they\'ll all think me for asking! No, it\'ll never do to hold it. As soon as it went, \'One.',4.00,8,3,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(56,'Mock Turtle interrupted, \'if you only kept on good terms with him, he\'d do almost anything you.',3.00,3,6,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(57,'For the Mouse replied rather crossly: \'of course you don\'t!\' the Hatter instead!\' CHAPTER VII. A.',2.00,8,36,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(58,'Alice; \'I might as well as she could, \'If you do. I\'ll set Dinah at you!\' There was exactly three.',1.00,5,24,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(59,'Mock Turtle, and said nothing. \'This here young lady,\' said the Mock Turtle said: \'I\'m too stiff.',1.00,7,1,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(60,'Alice. \'But you\'re so easily offended, you know!\' The Mouse did not come the same height as.',3.00,7,26,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(61,'Seaography: then Drawling--the Drawling-master was an immense length of neck, which seemed to be.',3.00,7,13,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(62,'I grow up, I\'ll write one--but I\'m grown up now,\' she added in a very good height indeed!\' said.',2.00,8,12,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(63,'Alice could not remember the simple and loving heart of her voice. Nobody moved. \'Who cares for.',1.00,7,11,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(64,'The twelve jurors were all talking together: she made her so savage when they met in the last word.',4.00,3,22,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(65,'NEVER come to the jury, and the words don\'t FIT you,\' said the youth, \'one would hardly suppose.',1.00,8,23,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(66,'Dodo solemnly presented the thimble, looking as solemn as she could, and soon found herself at.',1.00,7,26,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(67,'King was the cat.) \'I hope they\'ll remember her saucer of milk at tea-time. Dinah my dear! I shall.',2.00,7,19,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(68,'I did: there\'s no use in the window?\' \'Sure, it\'s an arm, yer honour!\' (He pronounced it \'arrum.\').',5.00,5,30,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(69,'Alice. \'And where HAVE my shoulders got to? And oh, I wish you wouldn\'t keep appearing and.',4.00,3,36,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(70,'Mock Turtle with a trumpet in one hand and a sad tale!\' said the Cat; and this he handed over to.',2.00,3,37,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(71,'Majesty,\' the Hatter with a sudden leap out of sight, he said to Alice, they all spoke at once.',1.00,5,13,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(72,'Gryphon replied rather crossly: \'of course you know the meaning of half an hour or so there were.',3.00,5,6,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(73,'King triumphantly, pointing to Alice severely. \'What are tarts made of?\' \'Pepper, mostly,\' said.',1.00,5,13,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(74,'Rome, and Rome--no, THAT\'S all wrong, I\'m certain! I must be a lesson to you how the game began.',5.00,7,31,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(75,'Oh, how I wish you wouldn\'t mind,\' said Alice: \'I don\'t believe there\'s an atom of meaning in it.',2.00,5,12,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(76,'I\'ve had such a thing. After a while she was a paper label, with the birds hurried off at once.',2.00,5,31,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(77,'She had already heard her voice close to her daughter \'Ah, my dear! Let this be a person of.',5.00,7,21,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(78,'Caterpillar, just as well. The twelve jurors were all turning into little cakes as they came.',1.00,7,4,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(79,'I look like one, but it was getting so thin--and the twinkling of the water, and seemed to have.',4.00,8,12,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(80,'Queen,\' and she looked back once or twice, and shook itself. Then it got down off the fire.',4.00,3,30,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(81,'Alice replied, so eagerly that the poor little feet, I wonder if I must, I must,\' the King said.',5.00,5,28,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(82,'Lizard, Bill, was in March.\' As she said to herself; \'I should think very likely to eat some of.',3.00,3,1,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(83,'I can guess that,\' she added aloud. \'Do you mean \"purpose\"?\' said Alice. \'Nothing WHATEVER?\'.',3.00,3,37,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(84,'Seaography: then Drawling--the Drawling-master was an old crab, HE was.\' \'I never went to school.',5.00,8,13,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(85,'Just then she had not the smallest idea how confusing it is right?\' \'In my youth,\' Father William.',3.00,7,12,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(86,'Edwin and Morcar, the earls of Mercia and Northumbria, declared for him: and even Stigand, the.',4.00,8,38,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(87,'The Duchess took her choice, and was going to leave it behind?\' She said the March Hare and the.',4.00,8,38,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(88,'March Hare. \'Then it wasn\'t very civil of you to death.\"\' \'You are old,\' said the King, with an.',2.00,3,38,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(89,'Mabel, for I know is, something comes at me like a steam-engine when she had plenty of time as she.',5.00,5,19,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(90,'So she set to work, and very neatly and simply arranged; the only one who had been would have.',1.00,7,9,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(91,'After these came the royal children, and make out who I am! But I\'d better take him his fan and a.',3.00,7,8,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(92,'Do cats eat bats? Do cats eat bats? Do cats eat bats, I wonder?\' Alice guessed in a bit.\' \'Perhaps.',3.00,8,33,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(93,'I almost wish I could shut up like telescopes: this time the Mouse in the distance would take the.',2.00,8,40,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(94,'Queen, who was reading the list of the room. The cook threw a frying-pan after her as hard as she.',2.00,5,9,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(95,'Then it got down off the fire, and at once without waiting for the first witness,\' said the Dodo.',2.00,7,37,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(96,'And she began thinking over all the time she saw in my size; and as Alice could think of what work.',1.00,8,28,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(97,'I ever heard!\' \'Yes, I think I could, if I chose,\' the Duchess began in a deep sigh, \'I was a.',5.00,7,7,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(98,'Alice. \'Only a thimble,\' said Alice sadly. \'Hand it over here,\' said the Mock Turtle. \'Seals.',2.00,7,35,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(99,'Mock Turtle in the sun. (IF you don\'t know what a delightful thing a bit!\' said the sage, as he.',2.00,5,34,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(100,'Hatter, \'you wouldn\'t talk about wasting IT. It\'s HIM.\' \'I don\'t believe you do either!\' And the.',1.00,7,13,'2022-05-17 07:26:20','2022-05-17 07:26:20');
/*!40000 ALTER TABLE `e_service_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_services`
--

DROP TABLE IF EXISTS `e_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `e_services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_ci,
  `price` double(10,2) NOT NULL DEFAULT '0.00',
  `discount_price` double(10,2) DEFAULT '0.00',
  `price_unit` enum('hourly','fixed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity_unit` longtext COLLATE utf8mb4_unicode_ci,
  `duration` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `featured` tinyint(1) DEFAULT '0',
  `enable_booking` tinyint(1) DEFAULT '1',
  `available` tinyint(1) DEFAULT '1',
  `e_provider_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `e_services_e_provider_id_foreign` (`e_provider_id`),
  CONSTRAINT `e_services_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_services`
--

LOCK TABLES `e_services` WRITE;
/*!40000 ALTER TABLE `e_services` DISABLE KEYS */;
INSERT INTO `e_services` (`id`, `name`, `price`, `discount_price`, `price_unit`, `quantity_unit`, `duration`, `description`, `featured`, `enable_booking`, `available`, `e_provider_id`, `created_at`, `updated_at`) VALUES (1,'{\"en\":\"Sedan Car Washing \"}',23.20,13.99,'hourly',NULL,'3:00','{\"en\":\"Officiis et praesentium cumque repudiandae eum cumque possimus et. Consectetur cupiditate non nihil. Est error ut iusto consequatur harum. Perspiciatis omnis omnis iusto debitis.\"}',0,0,0,17,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(2,'{\"en\":\"Flooring Services\"}',20.49,19.15,'hourly',NULL,'1:00','{\"en\":\"Doloribus fugit incidunt quibusdam inventore aliquam expedita. Ab fugit hic minima dolor et omnis.\"}',1,0,1,18,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(3,'{\"en\":\"Lawn Care Services\"}',20.26,14.27,'fixed',NULL,'2:00','{\"en\":\"Ea officia facilis in deleniti laborum accusamus. Nesciunt neque voluptates eos nihil. Perspiciatis ratione autem ratione aut tenetur.\"}',1,1,0,6,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(4,'{\"en\":\"Office Cleaning\"}',28.59,23.24,'fixed',NULL,'2:00','{\"en\":\"Nulla ipsa omnis doloribus beatae aut ea amet vitae. Molestiae doloremque ea quia id accusamus. Aut consectetur sit reiciendis ut quia dolorem omnis. Et doloremque doloribus quod quo eum et.\"}',1,0,0,17,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(5,'{\"en\":\"Architect Service\"}',47.01,39.40,'hourly',NULL,'5:00','{\"en\":\"Sint libero harum quia ut neque. Aperiam numquam rerum dolore sed in. Ipsam perspiciatis et cupiditate.\"}',0,0,1,18,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(6,'{\"en\":\"Doctor at home Service\"}',46.10,0.00,'hourly',NULL,'1:00','{\"en\":\"Ea et voluptatibus quisquam quia corporis et impedit voluptatem. Placeat ut voluptas doloremque aut. Rerum provident amet et cum magni eligendi suscipit. Unde nihil et sunt est commodi.\"}',0,0,1,15,'2022-05-17 07:26:17','2022-05-17 07:26:17'),(7,'{\"en\":\"Architect Service\"}',43.65,37.23,'hourly',NULL,'1:00','{\"en\":\"Voluptatum est consectetur earum necessitatibus voluptatem enim sapiente. Vel ea sit ducimus cumque.\"}',0,1,0,8,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(8,'{\"en\":\"Full Home Deep Cleaning\"}',11.50,0.00,'fixed',NULL,'3:00','{\"en\":\"Blanditiis soluta fugiat ducimus. Voluptas quis incidunt perspiciatis blanditiis beatae magnam tempore qui. Et adipisci vel amet autem quas qui. Modi fugiat sed fugiat voluptatibus voluptas voluptas.\"}',1,1,1,10,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(9,'{\"en\":\"Office Cleaning\"}',16.57,0.00,'hourly',NULL,'5:00','{\"en\":\"Eum cumque ullam dolor. Dignissimos sed maiores pariatur.\"}',1,1,1,7,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(10,'{\"en\":\"Doctor at home Service\"}',22.33,0.00,'fixed',NULL,'5:00','{\"en\":\"Qui id numquam reiciendis molestiae et facere culpa. Nihil neque delectus officiis et harum. Occaecati atque dicta consequatur hic.\"}',0,0,0,1,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(11,'{\"en\":\"Makeup & Beauty Services\"}',34.56,26.42,'fixed',NULL,'5:00','{\"en\":\"Placeat ea autem et veniam modi debitis. Non temporibus vel omnis sunt assumenda minus temporibus.\"}',1,0,0,4,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(12,'{\"en\":\"Full Home Deep Cleaning\"}',33.68,0.00,'fixed',NULL,'2:00','{\"en\":\"Explicabo eos voluptatem rerum. Consequatur delectus et est facere labore voluptatem magni. Earum rerum et atque qui vel ut. Autem reprehenderit aspernatur dolorem est nulla excepturi.\"}',0,1,0,10,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(13,'{\"en\":\"Makeup & Beauty Services\"}',36.95,34.93,'fixed',NULL,'3:00','{\"en\":\"Sunt quia doloremque pariatur et qui itaque laudantium aperiam. Et sit consequatur nam autem facilis. Expedita dolorem est impedit dolor tempora. Itaque recusandae architecto autem eius aut.\"}',0,0,0,16,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(14,'{\"en\":\"Sedan Car Washing \"}',45.02,38.51,'hourly',NULL,'4:00','{\"en\":\"Earum et et eveniet deserunt. Laudantium sapiente ducimus consequuntur. Aut deserunt placeat sed et est.\"}',0,1,0,18,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(15,'{\"en\":\"Nurse Service\"}',31.51,0.00,'fixed',NULL,'2:00','{\"en\":\"Voluptates libero itaque quos tempora et. Expedita doloremque doloribus atque facere. Facere eum qui sit necessitatibus. Molestiae ipsum iste quo commodi alias repellendus repellendus.\"}',1,1,0,2,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(16,'{\"en\":\"Tank Cleaning\"}',16.68,0.00,'fixed',NULL,'4:00','{\"en\":\"Vel est qui fuga eum aliquam modi. Earum voluptate aliquam ea et sed. Sunt animi ipsum ea reiciendis neque.\"}',0,1,1,17,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(17,'{\"en\":\"Facials Services\"}',16.03,11.06,'hourly',NULL,'4:00','{\"en\":\"Aut ea ad et non. Repellendus aut repellendus debitis quaerat debitis impedit eius. Eos consequatur rerum et incidunt officia hic dolores. Id ratione distinctio et saepe ex tenetur.\"}',1,1,0,5,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(18,'{\"en\":\"Screens - New and Repair\"}',39.63,0.00,'hourly',NULL,'2:00','{\"en\":\"Reiciendis assumenda eaque dignissimos eum ipsum. Nihil aut et debitis saepe culpa non. Aut saepe quasi pariatur qui qui. Reiciendis quam ex dicta eum pariatur quod.\"}',1,1,0,10,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(19,'{\"en\":\"Bathtub Refinishing\"}',33.16,31.60,'fixed',NULL,'5:00','{\"en\":\"Nihil nemo beatae qui ea accusantium. Officia non sit eligendi expedita. Deserunt exercitationem et ut nulla ullam.\"}',0,1,0,1,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(20,'{\"en\":\"Flooring Services\"}',14.55,10.03,'fixed',NULL,'4:00','{\"en\":\"Tempore et corrupti iure quia. Eos fugit ratione non impedit. Qui ad consequatur architecto ipsam laboriosam.\"}',1,0,0,10,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(21,'{\"en\":\"Wedding Photos\"}',13.14,3.61,'fixed',NULL,'1:00','{\"en\":\"Illum voluptas laborum ut vitae rerum cum omnis. Earum praesentium unde et. Quidem molestiae minima eos eveniet. Velit dignissimos unde dolores similique.\"}',0,1,1,17,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(22,'{\"en\":\"Thai Massage Services\"}',21.34,0.00,'fixed',NULL,'4:00','{\"en\":\"Repellat dolor sapiente officia. Magnam omnis amet ad rerum. Illum dolorem voluptas sequi nisi.\"}',0,0,0,10,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(23,'{\"en\":\"Nurse Service\"}',36.85,0.00,'hourly',NULL,'5:00','{\"en\":\"Molestiae eos laborum aperiam laborum blanditiis molestiae. Ut mollitia voluptatum sed quaerat. Assumenda nemo perferendis sunt natus voluptatem.\"}',1,0,1,16,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(24,'{\"en\":\"Portrait Photos Services\"}',19.43,0.00,'fixed',NULL,'5:00','{\"en\":\"Blanditiis ea consequuntur expedita numquam qui delectus. Dolorum voluptatem aliquam praesentium earum incidunt eaque.\"}',1,1,1,2,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(25,'{\"en\":\"Suv Car Washing \"}',48.81,0.00,'hourly',NULL,'5:00','{\"en\":\"Quidem deserunt provident ratione totam nam nostrum non possimus. Ut perspiciatis dolorem voluptas minima. Doloremque eum dolorum tempora id quis et.\"}',0,1,0,16,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(26,'{\"en\":\"Thai Massage Services\"}',31.14,0.00,'hourly',NULL,'4:00','{\"en\":\"Itaque adipisci recusandae velit facilis aliquam. Accusamus non laudantium quis quibusdam. Incidunt et rerum nesciunt unde. Iusto veniam atque dolor ea. Et consectetur blanditiis odio esse non et.\"}',1,0,1,7,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(27,'{\"en\":\"Hair Style Service\"}',40.78,32.16,'fixed',NULL,'2:00','{\"en\":\"Maiores eius commodi autem aliquam fugit. Pariatur totam explicabo incidunt voluptas et et. Et occaecati sunt sit explicabo corporis provident officia. Deleniti nemo non in aut.\"}',1,0,0,14,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(28,'{\"en\":\"Thai Massage Services\"}',14.68,0.00,'hourly',NULL,'1:00','{\"en\":\"Quos adipisci et qui. In sit est vitae accusantium et. Optio dolorum doloribus occaecati exercitationem magnam minima quibusdam.\"}',1,0,0,15,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(29,'{\"en\":\"Suv Car Washing \"}',10.76,0.00,'fixed',NULL,'5:00','{\"en\":\"Nihil est suscipit magnam et et eius. Ut aut facilis et esse occaecati nihil ex.\"}',1,0,0,9,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(30,'{\"en\":\"Real Estate Agents\"}',43.36,0.00,'hourly',NULL,'4:00','{\"en\":\"Sint eos repellendus nihil voluptatem perferendis aliquam. Officiis aut omnis aut unde doloribus voluptas laboriosam quisquam. Et mollitia dolores non suscipit.\"}',1,0,1,6,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(31,'{\"en\":\"Real Estate Agents\"}',22.77,0.00,'hourly',NULL,'4:00','{\"en\":\"Aliquid eaque quam sint. Eius commodi cum illo iure fuga. Saepe fugit vel pariatur eius qui.\"}',0,0,0,10,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(32,'{\"en\":\"Screens - New and Repair\"}',34.90,30.33,'hourly',NULL,'5:00','{\"en\":\"Dolores placeat impedit ea veniam. Ut ut repellendus est omnis. Doloremque esse non eum harum iste corrupti odio. Et facilis reprehenderit iusto temporibus dignissimos eius repellat.\"}',0,1,1,8,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(33,'{\"en\":\"Thai Massage Services\"}',33.74,0.00,'hourly',NULL,'2:00','{\"en\":\"Qui corporis dignissimos at consectetur voluptatem. Non architecto facere ipsam ad molestiae aperiam in. Architecto impedit vitae vero autem.\"}',1,1,0,16,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(34,'{\"en\":\"Hair Style Service\"}',23.11,0.00,'fixed',NULL,'5:00','{\"en\":\"In amet dolor ut in. Sit consequatur repudiandae nihil quis. Itaque enim magni sit doloribus veritatis. Nesciunt id consequatur odio deserunt.\"}',0,1,1,1,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(35,'{\"en\":\"Sedan Car Washing\"}',44.55,0.00,'fixed','{\"en\":null}','5:00','{\"en\":\"Eos est et provident rem omnis minima earum. Neque hic illum quisquam doloribus autem dolorem. Et iste culpa eum soluta. Illum optio itaque nihil cumque ipsam. Autem debitis a aliquam iure.\"}',0,0,1,12,'2022-05-17 07:26:18','2022-05-18 09:12:53'),(36,'{\"en\":\"Architect Service\"}',19.45,0.00,'fixed',NULL,'3:00','{\"en\":\"Molestiae cumque ratione architecto sit eos nisi. Doloribus facilis magni quas. Non modi quisquam possimus suscipit laboriosam quod deserunt.\"}',0,1,0,4,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(37,'{\"en\":\"Sedan Car Washing \"}',34.91,0.00,'hourly',NULL,'2:00','{\"en\":\"Id amet id velit asperiores qui. Quasi consectetur quos minima hic quae rerum laborum. Ea repellendus molestias ipsam mollitia vel. Ex asperiores ducimus sapiente neque quia.\"}',0,1,0,3,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(38,'{\"en\":\"Suv Car Washing \"}',34.31,0.00,'hourly',NULL,'1:00','{\"en\":\"Asperiores eaque quos ut voluptatem molestiae maxime autem. Ut rerum excepturi accusantium dolor est. Sit sequi aut qui. Voluptatem molestiae voluptatem autem incidunt explicabo sint quo possimus.\"}',0,0,1,11,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(39,'{\"en\":\"Makeup & Beauty Services\"}',32.46,24.88,'hourly',NULL,'4:00','{\"en\":\"Distinctio dolorem fuga dolorem qui blanditiis quia et. Aut nihil est nihil voluptate quia. Non velit nulla sit recusandae numquam qui.\"}',0,0,0,16,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(40,'{\"en\":\"Bathtub Refinishing\"}',25.37,0.00,'fixed',NULL,'1:00','{\"en\":\"Ullam iste doloribus quasi molestiae deleniti veritatis consequuntur odio. Distinctio esse consequatur repudiandae. Corrupti nemo totam est nostrum.\"}',0,1,1,3,'2022-05-17 07:26:18','2022-05-17 07:26:18');
/*!40000 ALTER TABLE `e_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `earnings`
--

DROP TABLE IF EXISTS `earnings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `earnings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `e_provider_id` int(10) unsigned DEFAULT NULL,
  `total_bookings` int(10) unsigned NOT NULL DEFAULT '0',
  `total_earning` double(10,2) NOT NULL DEFAULT '0.00',
  `admin_earning` double(10,2) NOT NULL DEFAULT '0.00',
  `e_provider_earning` double(10,2) NOT NULL DEFAULT '0.00',
  `taxes` double(10,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `earnings_e_provider_id_foreign` (`e_provider_id`),
  CONSTRAINT `earnings_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `earnings`
--

LOCK TABLES `earnings` WRITE;
/*!40000 ALTER TABLE `earnings` DISABLE KEYS */;
/*!40000 ALTER TABLE `earnings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experiences`
--

DROP TABLE IF EXISTS `experiences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `experiences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext COLLATE utf8mb4_unicode_ci,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `e_provider_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `experiences_e_provider_id_foreign` (`e_provider_id`),
  CONSTRAINT `experiences_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experiences`
--

LOCK TABLES `experiences` WRITE;
/*!40000 ALTER TABLE `experiences` DISABLE KEYS */;
INSERT INTO `experiences` (`id`, `title`, `description`, `e_provider_id`, `created_at`, `updated_at`) VALUES (1,'{\"en\":\"Deleniti quas exercitationem aut consequatur. Soluta nihil cumque similique delectus enim saepe voluptas.\"}','{\"en\":\"Ann, and be turned out of the hall: in fact she was now more than Alice could bear: she got up, and there they lay sprawling about, reminding her very much pleased at having found out that part.\'.\"}',8,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(2,'{\"en\":\"Commodi ut dolores facilis iusto aperiam. Beatae corrupti ut est veniam ut. Quo sunt earum quis eum velit eum.\"}','{\"en\":\"I WAS when I find a thing,\' said the Duchess. An invitation from the Queen to play croquet.\' The Frog-Footman repeated, in the pool, \'and she sits purring so nicely by the time when I learn music.\'.\"}',10,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(3,'{\"en\":\"Eum natus sapiente illum provident molestias minima. Repudiandae et quam maiores. Sapiente id saepe architecto adipisci.\"}','{\"en\":\"Alice, and she tried her best to climb up one of these cakes,\' she thought, \'it\'s sure to make personal remarks,\' Alice said nothing; she had got to the Queen, turning purple. \'I won\'t!\' said Alice.\"}',5,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(4,'{\"en\":\"Ut accusamus quia voluptatem. Molestiae ad architecto alias eius. Velit nemo autem tempore nihil iusto et ea libero.\"}','{\"en\":\"Alice (she was so full of the jurymen. \'It isn\'t a bird,\' Alice remarked. \'Right, as usual,\' said the Cat. \'I\'d nearly forgotten that I\'ve got to the dance. Will you, won\'t you, won\'t you, will you.\"}',12,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(5,'{\"en\":\"Magnam sunt dolorem quis eos aut. Aut sequi consequuntur ut itaque expedita dicta doloribus. Earum magni dolorem quod amet.\"}','{\"en\":\"It quite makes my forehead ache!\' Alice watched the Queen put on his flappers, \'--Mystery, ancient and modern, with Seaography: then Drawling--the Drawling-master was an old conger-eel, that used to.\"}',15,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(6,'{\"en\":\"Veritatis ex et aut saepe nulla. A quia et a possimus ea. Ut magnam ut ipsum debitis.\"}','{\"en\":\"However, on the bank, with her head! Off--\' \'Nonsense!\' said Alice, in a piteous tone. And the Gryphon as if it wasn\'t very civil of you to death.\\\"\' \'You are all pardoned.\' \'Come, THAT\'S a good deal.\"}',2,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(7,'{\"en\":\"Laboriosam repudiandae vel molestiae cupiditate libero accusamus ut omnis. Sint omnis ipsam sed illo similique.\"}','{\"en\":\"Why, it fills the whole head appeared, and then hurried on, Alice started to her head, she tried the little door, had vanished completely. Very soon the Rabbit actually TOOK A WATCH OUT OF ITS.\"}',13,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(8,'{\"en\":\"Illo distinctio aliquid sed est unde. Veritatis repellendus in quas tempora fugit perferendis.\"}','{\"en\":\"Him, and ourselves, and it. Don\'t let him know she liked them best, For this must ever be A secret, kept from all the right word) \'--but I shall only look up in great disgust, and walked off; the.\"}',2,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(9,'{\"en\":\"Consequatur at enim qui. Tempora iste ut aut et dolorum vel consequuntur sint. Vel libero dolore error quis.\"}','{\"en\":\"Alice herself, and nibbled a little hot tea upon its nose. The Dormouse again took a minute or two she walked down the little door was shut again, and Alice called after it; and the blades of grass.\"}',8,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(10,'{\"en\":\"Sequi natus eaque sit id autem est quas. Voluptatem vel quibusdam aut. Excepturi soluta repellat officiis natus.\"}','{\"en\":\"Alice a little bird as soon as it lasted.) \'Then the Dormouse began in a sulky tone; \'Seven jogged my elbow.\' On which Seven looked up eagerly, half hoping she might find another key on it, for she.\"}',14,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(11,'{\"en\":\"Sed neque nostrum est. Quasi harum aut et reprehenderit unde. Harum quas quod quos consequatur est aperiam nam.\"}','{\"en\":\"She said it to speak again. The Mock Turtle at last, more calmly, though still sobbing a little nervous about it while the Mock Turtle with a great hurry to change the subject,\' the March Hare.\"}',18,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(12,'{\"en\":\"Nostrum voluptate dolore eos aut tempora. Aut nobis est aliquam dolores quia eos excepturi quo. Sit qui corporis totam qui.\"}','{\"en\":\"Cheshire cats always grinned; in fact, I didn\'t know that Cheshire cats always grinned; in fact, a sort of knot, and then the Rabbit\'s voice; and Alice looked up, but it did not get dry again: they.\"}',16,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(13,'{\"en\":\"Aut odio fuga ratione natus. Et et praesentium culpa facilis eos.\"}','{\"en\":\"Gryphon. \'We can do no more, whatever happens. What WILL become of you? I gave her one, they gave him two, You gave us three or more; They all made a memorandum of the cupboards as she remembered.\"}',2,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(14,'{\"en\":\"Nemo doloribus enim harum maxime. Sunt repudiandae sunt quibusdam error et sed et quod. Aliquam cumque qui iusto vel.\"}','{\"en\":\"BEST butter, you know.\' It was, no doubt: only Alice did not venture to ask any more HERE.\' \'But then,\' thought Alice, as she listened, or seemed to be sure; but I THINK I can find out the words.\"}',14,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(15,'{\"en\":\"Eligendi ducimus nihil quaerat magni. Quia ex quo nulla at.\"}','{\"en\":\"I ever saw one that size? Why, it fills the whole head appeared, and then unrolled the parchment scroll, and read as follows:-- \'The Queen of Hearts, he stole those tarts, And took them quite away!\'.\"}',12,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(16,'{\"en\":\"Vero voluptate nihil dolorem cumque. Totam enim aut doloribus id. Qui dolor sed provident et culpa veniam occaecati.\"}','{\"en\":\"Cat. \'--so long as I used--and I don\'t know,\' he went on in a sulky tone, as it can be,\' said the Caterpillar. Alice thought she might as well look and see what I could not think of anything to put.\"}',4,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(17,'{\"en\":\"Magni voluptas dolor eum corporis. Sed modi sed aut excepturi sit. Magni perferendis sint possimus.\"}','{\"en\":\"King was the fan and a piece of it had come back again, and we won\'t talk about her repeating \'YOU ARE OLD, FATHER WILLIAM,\\\"\' said the Gryphon: and it put more simply--\\\"Never imagine yourself not to.\"}',18,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(18,'{\"en\":\"Id optio ea autem doloremque. Aut nisi quo est nam laborum eius. Est repellat autem ab.\"}','{\"en\":\"The Gryphon lifted up both its paws in surprise. \'What! Never heard of \\\"Uglification,\\\"\' Alice ventured to taste it, and burning with curiosity, she ran with all her life. Indeed, she had never seen.\"}',18,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(19,'{\"en\":\"Delectus commodi velit et. Nostrum doloribus ad id eos magnam omnis. Atque amet maxime necessitatibus molestiae.\"}','{\"en\":\"The Mouse did not come the same words as before, \'It\'s all his fancy, that: they never executes nobody, you know. Come on!\' So they got settled down again, the cook was leaning over the list.\"}',17,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(20,'{\"en\":\"Veritatis quibusdam ad nesciunt. Velit ut natus facere quidem. Deleniti provident qui repellendus consectetur.\"}','{\"en\":\"I wonder?\' Alice guessed who it was, even before she had felt quite unhappy at the Hatter, and he checked himself suddenly: the others took the thimble, saying \'We beg your acceptance of this sort.\"}',11,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(21,'{\"en\":\"Et in commodi tempora molestias voluptate. Et autem animi ut adipisci. Quibusdam aspernatur dolores atque.\"}','{\"en\":\"Cheshire Cat,\' said Alice: \'allow me to him: She gave me a pair of white kid gloves while she was shrinking rapidly; so she began thinking over other children she knew that it is!\' \'Why should it?\'.\"}',18,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(22,'{\"en\":\"Et ut quam et. Quo voluptatibus reprehenderit incidunt at dolorum exercitationem.\"}','{\"en\":\"Alice did not seem to be\\\"--or if you\'d like it put more simply--\\\"Never imagine yourself not to be ashamed of yourself for asking such a very grave voice, \'until all the first figure,\' said the.\"}',10,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(23,'{\"en\":\"Itaque id non vel. Quibusdam quia quidem corrupti sunt libero repudiandae. Culpa voluptas corporis adipisci labore.\"}','{\"en\":\"I shan\'t go, at any rate,\' said Alice: \'I don\'t think they play at all like the three were all writing very busily on slates. \'What are you getting on?\' said Alice, as she came up to the whiting,\'.\"}',8,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(24,'{\"en\":\"Tempore tenetur nostrum id rem unde. Quas sequi atque qui sequi quia sed.\"}','{\"en\":\"And Alice was a bright brass plate with the bread-knife.\' The March Hare and the procession moved on, three of her head through the neighbouring pool--she could hear the Rabbit began. Alice thought.\"}',3,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(25,'{\"en\":\"Et velit voluptatum tenetur nobis et. Minima est et fugit est ut cum quae eaque. Et totam enim voluptatem commodi.\"}','{\"en\":\"Dinah, and saying \\\"Come up again, dear!\\\" I shall remember it in less than a pig, my dear,\' said Alice, \'it\'s very interesting. I never knew so much at this, she noticed a curious feeling!\' said.\"}',8,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(26,'{\"en\":\"Placeat quia quasi occaecati. Maxime qui alias dolor tempora delectus. Saepe molestiae culpa omnis non inventore laborum.\"}','{\"en\":\"Footman, \'and that for two Pennyworth only of beautiful Soup? Beau--ootiful Soo--oop! Soo--oop of the song, she kept fanning herself all the party were placed along the passage into the wood. \'If it.\"}',10,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(27,'{\"en\":\"Eos quod consectetur aspernatur aperiam. Minus voluptas voluptatum corporis quae. Voluptatum tenetur enim quis optio aliquid.\"}','{\"en\":\"Hatter trembled so, that Alice had got burnt, and eaten up by two guinea-pigs, who were lying on their backs was the BEST butter, you know.\' \'I DON\'T know,\' said the Hatter: \'but you could keep it.\"}',7,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(28,'{\"en\":\"Architecto quia autem et rerum modi et. Perferendis voluptatem quos voluptatum omnis aut eum. Sit et tempore autem.\"}','{\"en\":\"Alice, so please your Majesty,\' said the Duchess, it had VERY long claws and a large crowd collected round it: there was no time she\'d have everybody executed, all round. (It was this last remark.\"}',13,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(29,'{\"en\":\"Architecto fugiat et magni odio sint aliquid et quis. Soluta aut sunt quia unde reiciendis.\"}','{\"en\":\"Time as well as pigs, and was beating her violently with its tongue hanging out of a treacle-well--eh, stupid?\' \'But they were nowhere to be afraid of it. Presently the Rabbit noticed Alice, as the.\"}',1,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(30,'{\"en\":\"Architecto ut vitae sint consequatur veniam sit. Quod est rerum doloribus. Qui consequatur expedita voluptatem sint.\"}','{\"en\":\"I should like to hear the very middle of one! There ought to speak, and no one could possibly hear you.\' And certainly there was a dead silence instantly, and neither of the house!\' (Which was very.\"}',5,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(31,'{\"en\":\"Quaerat aut sed nostrum et. Iure assumenda cum vel quis. Assumenda commodi adipisci repellat maiores perferendis veniam sunt.\"}','{\"en\":\"Where are you?\' And then a row of lamps hanging from the shock of being upset, and their curls got entangled together. Alice laughed so much already, that it was only too glad to find that she began.\"}',7,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(32,'{\"en\":\"Quod odio atque voluptatem ipsum. Nulla iure blanditiis dignissimos tempora. In amet laudantium et aut veniam perferendis ab.\"}','{\"en\":\"King, and the words have got into the garden door. Poor Alice! It was so ordered about by mice and rabbits. I almost think I must go back and see after some executions I have to whisper a hint to.\"}',14,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(33,'{\"en\":\"Ullam in rerum sit et officiis. Atque at impedit qui error. Dolorem recusandae consequatur ut et.\"}','{\"en\":\"I to get through was more and more faintly came, carried on the trumpet, and then said, \'It WAS a curious appearance in the pictures of him), while the Dodo solemnly presented the thimble, looking.\"}',6,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(34,'{\"en\":\"Et et amet aliquid maxime voluptas voluptas occaecati. Doloremque quae iusto non. Voluptates corrupti reprehenderit provident.\"}','{\"en\":\"Alice ventured to remark. \'Tut, tut, child!\' said the Mock Turtle in a fight with another dig of her childhood: and how she was now about two feet high, and her eyes immediately met those of a.\"}',5,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(35,'{\"en\":\"Et quam error qui deserunt. Nostrum veniam et ullam similique repellat.\"}','{\"en\":\"VERY good opportunity for showing off her knowledge, as there was the only one who got any advantage from the sky! Ugh, Serpent!\' \'But I\'m not looking for eggs, as it settled down again, the cook.\"}',2,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(36,'{\"en\":\"Enim ut architecto non vitae. Rerum consequuntur delectus quibusdam nobis aut eos.\"}','{\"en\":\"Duchess by this time, and was just in time to see it quite plainly through the little door, so she went down to nine inches high. CHAPTER VI. Pig and Pepper For a minute or two, which gave the.\"}',11,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(37,'{\"en\":\"Et est id iste repellendus. Et pariatur vero ullam. Ut laboriosam animi asperiores reprehenderit tempore rerum.\"}','{\"en\":\"She was a dead silence. \'It\'s a pun!\' the King replied. Here the Queen was close behind us, and he\'s treading on her toes when they liked, so that her shoulders were nowhere to be ashamed of.\"}',7,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(38,'{\"en\":\"Dolorum et quia recusandae et ipsa. Veniam fugiat et in enim quam. Inventore sequi expedita iste quod.\"}','{\"en\":\"In a minute or two, looking for eggs, as it settled down in a deep, hollow tone: \'sit down, both of you, and listen to her. The Cat seemed to think that will be When they take us up and ran the.\"}',18,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(39,'{\"en\":\"Ut quis possimus consequuntur. Ullam neque excepturi est iste praesentium quae. Repudiandae aliquam quis vel porro fugiat qui.\"}','{\"en\":\"I can say.\' This was not easy to know when the tide rises and sharks are around, His voice has a timid voice at her own mind (as well as she could, and waited till the puppy\'s bark sounded quite.\"}',7,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(40,'{\"en\":\"Et et magnam qui asperiores sit. Dolorem eum voluptatem non rerum facilis nesciunt. Eum qui et sed nemo.\"}','{\"en\":\"Hatter. \'It isn\'t directed at all,\' said the Caterpillar. \'Not QUITE right, I\'m afraid,\' said Alice, who felt very glad to do it?\' \'In my youth,\' Father William replied to his ear. Alice considered.\"}',11,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(41,'{\"en\":\"Ea qui aperiam harum id. Distinctio non est assumenda et libero. Id consequuntur optio tempore ut ut iste at sapiente.\"}','{\"en\":\"She was a little bottle that stood near the door, and knocked. \'There\'s no sort of idea that they could not make out at the bottom of a water-well,\' said the Mouse. \'Of course,\' the Mock Turtle.\"}',10,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(42,'{\"en\":\"At at non consequatur sit. Libero at necessitatibus enim quod itaque. Aliquam eum et libero et sequi.\"}','{\"en\":\"King was the Duchess\'s cook. She carried the pepper-box in her pocket, and pulled out a new kind of sob, \'I\'ve tried the little thing sat down with one of the Gryphon, sighing in his confusion he.\"}',12,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(43,'{\"en\":\"Et id iste minus quia. Sit occaecati voluptatem quia repudiandae.\"}','{\"en\":\"Gryphon, and, taking Alice by the pope, was soon submitted to by all three dates on their throne when they arrived, with a shiver. \'I beg your pardon!\' said the Hatter. \'I deny it!\' said the Mouse.\"}',3,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(44,'{\"en\":\"Ipsam quae nam distinctio est autem. Et aliquid sapiente non accusantium quia eum. Et nam aut reprehenderit sed autem.\"}','{\"en\":\"Queen\'s hedgehog just now, only it ran away when it grunted again, and looking at it uneasily, shaking it every now and then, \'we went to him,\' the Mock Turtle replied; \'and then the Mock Turtle to.\"}',3,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(45,'{\"en\":\"Minima pariatur hic odit quos quas repellat impedit. Perspiciatis nemo aspernatur est cumque.\"}','{\"en\":\"Mock Turtle, suddenly dropping his voice; and the Dormouse go on in the distance, and she went to the tarts on the glass table and the poor child, \'for I never understood what it meant till now.\'.\"}',9,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(46,'{\"en\":\"Dolore asperiores veritatis dolores beatae. Recusandae voluptas aspernatur sunt enim. Aut officiis dolores facere.\"}','{\"en\":\"Mock Turtle yet?\' \'No,\' said the King sharply. \'Do you know about it, you know--\' (pointing with his head!\' or \'Off with her head!\' Alice glanced rather anxiously at the March Hare took the watch.\"}',13,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(47,'{\"en\":\"Dolor qui distinctio quidem. Sit quas repellat id eos magnam pariatur et. Odit architecto magni voluptate modi enim et quia.\"}','{\"en\":\"Alice quietly said, just as if she were looking up into hers--she could hear the very tones of her voice. Nobody moved. \'Who cares for you?\' said the King; \'and don\'t look at the top of its little.\"}',7,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(48,'{\"en\":\"Sunt ullam non magnam laudantium aliquam. Aut iure vel in dolore sed quia ratione.\"}','{\"en\":\"ALICE\'S RIGHT FOOT, ESQ. HEARTHRUG, NEAR THE FENDER, (WITH ALICE\'S LOVE). Oh dear, what nonsense I\'m talking!\' Just then she remembered how small she was exactly three inches high). \'But I\'m NOT a.\"}',16,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(49,'{\"en\":\"Qui culpa et veniam ducimus porro qui. Quae explicabo dolor odit dolores maiores laudantium. Magni eum omnis vitae quis saepe.\"}','{\"en\":\"March--just before HE went mad, you know--\' \'What did they live on?\' said Alice, \'we learned French and music.\' \'And washing?\' said the Duchess, it had struck her foot! She was looking up into a.\"}',12,'2022-05-17 07:26:22','2022-05-17 07:26:22'),(50,'{\"en\":\"Ut quis voluptate accusantium. Odio et est reiciendis. Repudiandae unde iure eos eaque.\"}','{\"en\":\"WAS a narrow escape!\' said Alice, seriously, \'I\'ll have nothing more happened, she decided to remain where she was now about a foot high: then she noticed that they would go, and making faces at him.\"}',7,'2022-05-17 07:26:22','2022-05-17 07:26:22');
/*!40000 ALTER TABLE `experiences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_categories`
--

DROP TABLE IF EXISTS `faq_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_categories`
--

LOCK TABLES `faq_categories` WRITE;
/*!40000 ALTER TABLE `faq_categories` DISABLE KEYS */;
INSERT INTO `faq_categories` (`id`, `name`, `created_at`, `updated_at`) VALUES (1,'{\"en\":\"Service\"}','2022-05-17 07:26:17','2022-05-17 07:26:17'),(2,'{\"en\":\"Service\"}','2022-05-17 07:26:17','2022-05-17 07:26:17'),(3,'{\"en\":\"Service\"}','2022-05-17 07:26:17','2022-05-17 07:26:17'),(4,'{\"en\":\"Service\"}','2022-05-17 07:26:17','2022-05-17 07:26:17'),(5,'{\"en\":\"Service\"}','2022-05-17 07:26:17','2022-05-17 07:26:17');
/*!40000 ALTER TABLE `faq_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` longtext COLLATE utf8mb4_unicode_ci,
  `answer` longtext COLLATE utf8mb4_unicode_ci,
  `faq_category_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `faqs_faq_category_id_foreign` (`faq_category_id`),
  CONSTRAINT `faqs_faq_category_id_foreign` FOREIGN KEY (`faq_category_id`) REFERENCES `faq_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` (`id`, `question`, `answer`, `faq_category_id`, `created_at`, `updated_at`) VALUES (1,'{\"en\":\"Beatae exercitationem ut cum ut. Tempore est sint ullam voluptatem cum. Autem non aut ea.\"}','{\"en\":\"I\'ve fallen by this time). \'Don\'t grunt,\' said Alice; \'I might as well as she could, for her to speak first, \'why your cat grins like that?\' \'It\'s a friend of mine--a Cheshire Cat,\' said Alice.\"}',2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(2,'{\"en\":\"Sit unde dolore in animi. Tenetur qui recusandae officia.\"}','{\"en\":\"Alice. \'Call it what you mean,\' said Alice. \'I\'m glad they don\'t seem to put down the hall. After a time there could be no doubt that it signifies much,\' she said to herself \'Suppose it should be.\"}',1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(3,'{\"en\":\"Ducimus numquam voluptas aut neque sit. Et sed fuga eum. Iste rerum libero minus nulla et ut.\"}','{\"en\":\"Frog-Footman repeated, in the lock, and to stand on their hands and feet, to make out that one of them attempted to explain the mistake it had fallen into it: there was no label this time it.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(4,'{\"en\":\"Itaque ipsum odit quaerat magni ex a. Explicabo eius autem qui dicta recusandae optio voluptatibus.\"}','{\"en\":\"No room!\' they cried out when they saw her, they hurried back to her: its face in some book, but I grow at a king,\' said Alice. \'Nothing WHATEVER?\' persisted the King. The next witness would be.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(5,'{\"en\":\"Sit veniam molestias quam facere pariatur vitae. Aliquam at quos sit atque.\"}','{\"en\":\"Caterpillar. Here was another long passage, and the small ones choked and had just begun \'Well, of all her life. Indeed, she had not attended to this mouse? Everything is so out-of-the-way down.\"}',2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(6,'{\"en\":\"Repellat cum minima aut aut possimus nihil. Aliquam recusandae facere est.\"}','{\"en\":\"I\'ll manage better this time,\' she said, \'and see whether it\'s marked \\\"poison\\\" or not\'; for she had not the smallest notice of her age knew the right house, because the chimneys were shaped like the.\"}',2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(7,'{\"en\":\"Nostrum est et id. Aut ipsam quo magni eligendi qui. Ut velit ipsa ea et quia modi.\"}','{\"en\":\"Hatter were having tea at it: a Dormouse was sitting between them, fast asleep, and the cool fountains. CHAPTER VIII. The Queen\'s argument was, that if you don\'t explain it as far down the chimney!\'.\"}',2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(8,'{\"en\":\"Officia eaque animi magnam. Autem id quis odio et aliquid ullam fuga. Saepe dignissimos et non est.\"}','{\"en\":\"Mock Turtle said with a whiting. Now you know.\' \'Not the same as the other.\' As soon as the whole thing very absurd, but they all crowded round her, calling out in a fight with another dig of her.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(9,'{\"en\":\"Sit laudantium reprehenderit cum velit voluptatem. Vitae aut modi qui quisquam.\"}','{\"en\":\"King, and the arm that was linked into hers began to cry again. \'You ought to be treated with respect. \'Cheshire Puss,\' she began, rather timidly, as she couldn\'t answer either question, it didn\'t.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(10,'{\"en\":\"Sit sapiente vel et iste sequi. Esse quo nostrum non provident. Laboriosam quas ea laboriosam.\"}','{\"en\":\"Alice laughed so much already, that it led into the book her sister kissed her, and the little door into that lovely garden. First, however, she went on, taking first one side and then treading on.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(11,'{\"en\":\"Asperiores amet qui placeat architecto. Quia amet dolore quaerat eligendi.\"}','{\"en\":\"As soon as there seemed to think that proved it at all. However, \'jury-men\' would have done that, you know,\' said the Mouse, sharply and very neatly and simply arranged; the only difficulty was.\"}',1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(12,'{\"en\":\"Quisquam expedita vero qui nesciunt ut. Non veniam ut natus illum est ut rerum.\"}','{\"en\":\"CHAPTER III. A Caucus-Race and a Canary called out \'The Queen! The Queen!\' and the game was going to say,\' said the Mock Turtle recovered his voice, and, with tears running down his cheeks, he went.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(13,'{\"en\":\"Rerum vero rerum vero. Ullam magnam in consequatur quos rerum odio dolores.\"}','{\"en\":\"NOT a serpent, I tell you!\' But she waited patiently. \'Once,\' said the Dormouse, not choosing to notice this question, but hurriedly went on, looking anxiously about as she passed; it was all about.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(14,'{\"en\":\"Et quaerat cumque ut laudantium. Pariatur omnis assumenda voluptatem quidem aperiam reprehenderit.\"}','{\"en\":\"They all returned from him to be a walrus or hippopotamus, but then she walked off, leaving Alice alone with the next witness!\' said the Mock Turtle said: \'I\'m too stiff. And the Gryphon said to.\"}',1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(15,'{\"en\":\"Dolorem quibusdam sapiente dolorum nemo. Velit sit eos voluptatum necessitatibus ut iusto animi.\"}','{\"en\":\"Alice, and, after glaring at her rather inquisitively, and seemed not to make out exactly what they said. The executioner\'s argument was, that if something wasn\'t done about it while the rest were.\"}',1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(16,'{\"en\":\"Praesentium et eveniet labore blanditiis. Dicta non omnis aperiam. Provident sed ut quaerat ut.\"}','{\"en\":\"Alice. \'Off with his head!\\\"\' \'How dreadfully savage!\' exclaimed Alice. \'And ever since that,\' the Hatter went on to the waving of the same height as herself; and when she was always ready to play.\"}',2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(17,'{\"en\":\"Molestiae a veritatis a eaque fugit. Perferendis fugit quis eos culpa ut.\"}','{\"en\":\"Twinkle, twinkle--\\\"\' Here the Queen ordering off her unfortunate guests to execution--once more the pig-baby was sneezing and howling alternately without a porpoise.\' \'Wouldn\'t it really?\' said.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(18,'{\"en\":\"Quos ipsum quo nihil sed quo laborum quam. Dolorem consequatur veniam at perferendis et odit.\"}','{\"en\":\"Gryphon. \'Then, you know,\' the Hatter instead!\' CHAPTER VII. A Mad Tea-Party There was exactly three inches high). \'But I\'m not myself, you see.\' \'I don\'t see,\' said the White Rabbit read out, at.\"}',2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(19,'{\"en\":\"Veritatis corrupti fuga optio quo iusto. Molestias consequatur et blanditiis ea quis nostrum.\"}','{\"en\":\"Alice to herself, \'I wonder how many hours a day did you manage on the trumpet, and called out in a melancholy tone: \'it doesn\'t seem to have got altered.\' \'It is wrong from beginning to grow up any.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(20,'{\"en\":\"Natus reprehenderit ratione illum. Pariatur ut eaque est consequatur quisquam voluptatem.\"}','{\"en\":\"Queen,\' and she tried the effect of lying down on her spectacles, and began to repeat it, but her head to keep back the wandering hair that curled all over with fright. \'Oh, I know!\' exclaimed.\"}',4,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(21,'{\"en\":\"Est libero voluptas ad id. Suscipit exercitationem nesciunt voluptatibus saepe voluptas adipisci.\"}','{\"en\":\"Which way?\', holding her hand on the trumpet, and then a voice outside, and stopped to listen. \'Mary Ann! Mary Ann!\' said the Dormouse; \'--well in.\' This answer so confused poor Alice, that she knew.\"}',1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(22,'{\"en\":\"Quod non veniam ipsam fugit aut tempora at. Vero quasi ab dolorem ut harum. At illo sint qui culpa.\"}','{\"en\":\"Alice looked round, eager to see what was coming. It was high time to go, for the fan and gloves--that is, if I might venture to say which), and they lived at the Caterpillar\'s making such a thing.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(23,'{\"en\":\"In modi ut eaque reiciendis odit quo. Occaecati ea aut ut nostrum.\"}','{\"en\":\"And with that she could do, lying down on their slates, and then treading on her spectacles, and began to repeat it, but her voice sounded hoarse and strange, and the poor little thing sat down.\"}',2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(24,'{\"en\":\"Officia officia facilis eveniet facere sed ut odio. Totam placeat id debitis repudiandae vel.\"}','{\"en\":\"Five! Always lay the blame on others!\' \'YOU\'D better not do that again!\' which produced another dead silence. \'It\'s a friend of mine--a Cheshire Cat,\' said Alice: \'--where\'s the Duchess?\' \'Hush!.\"}',1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(25,'{\"en\":\"Animi qui fugit consectetur ex ad aut optio. Ut ad illo ex officiis qui dignissimos.\"}','{\"en\":\"Hatter said, turning to the conclusion that it was the Rabbit whispered in a helpless sort of thing never happened, and now here I am to see it quite plainly through the doorway; \'and even if my.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(26,'{\"en\":\"Aut sequi officiis est nisi at ullam consequatur. Est tempore qui velit nostrum et ad.\"}','{\"en\":\"King. \'It began with the next verse,\' the Gryphon in an offended tone, \'Hm! No accounting for tastes! Sing her \\\"Turtle Soup,\\\" will you, won\'t you, won\'t you, will you join the dance?\\\"\' \'Thank you.\"}',1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(27,'{\"en\":\"Et sunt sequi nesciunt velit odio. Deserunt minima a ut at eveniet vel odit in.\"}','{\"en\":\"Gryphon, and the sound of many footsteps, and Alice guessed in a moment: she looked up and down in an undertone to the Knave. The Knave did so, and were resting in the same side of WHAT?\' thought.\"}',1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(28,'{\"en\":\"Aliquid dolorum alias sequi. Minima quia assumenda excepturi sint molestiae provident consectetur.\"}','{\"en\":\"Mock Turtle, and to wonder what Latitude or Longitude I\'ve got to come out among the distant green leaves. As there seemed to be lost, as she couldn\'t answer either question, it didn\'t much matter.\"}',1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(29,'{\"en\":\"Qui vel aut id qui. Ad omnis et est in quasi. Ad voluptas est exercitationem quis.\"}','{\"en\":\"Like a tea-tray in the middle, being held up by wild beasts and other unpleasant things, all because they WOULD put their heads down and make one repeat lessons!\' thought Alice; \'I daresay it\'s a.\"}',2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(30,'{\"en\":\"Qui ad dolorem consectetur minus odit. Iusto mollitia sit neque velit. Ullam tempora culpa et non.\"}','{\"en\":\"Let me see: that would happen: \'\\\"Miss Alice! Come here directly, and get in at all?\' said Alice, who was reading the list of the song. \'What trial is it?\' he said. (Which he certainly did NOT, being.\"}',3,'2022-05-17 07:26:21','2022-05-17 07:26:21');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite_options`
--

DROP TABLE IF EXISTS `favorite_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorite_options` (
  `option_id` int(10) unsigned NOT NULL,
  `favorite_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`option_id`,`favorite_id`),
  KEY `favorite_options_favorite_id_foreign` (`favorite_id`),
  CONSTRAINT `favorite_options_favorite_id_foreign` FOREIGN KEY (`favorite_id`) REFERENCES `favorites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `favorite_options_option_id_foreign` FOREIGN KEY (`option_id`) REFERENCES `options` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite_options`
--

LOCK TABLES `favorite_options` WRITE;
/*!40000 ALTER TABLE `favorite_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorite_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `e_service_id` int(10) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `favorites_e_service_id_foreign` (`e_service_id`),
  KEY `favorites_user_id_foreign` (`user_id`),
  CONSTRAINT `favorites_e_service_id_foreign` FOREIGN KEY (`e_service_id`) REFERENCES `e_services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `favorites_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries`
--

DROP TABLE IF EXISTS `galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `e_provider_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `galleries_e_provider_id_foreign` (`e_provider_id`),
  CONSTRAINT `galleries_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries`
--

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
INSERT INTO `galleries` (`id`, `description`, `e_provider_id`, `created_at`, `updated_at`) VALUES (1,'{\"en\":\"Ea porro dolor commodi dolorem exercitationem at.\"}',4,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(2,'{\"en\":\"Dolorem nisi sed ut sit nulla.\"}',4,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(3,'{\"en\":\"Ab est vel quas provident ex.\"}',2,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(4,'{\"en\":\"Vero accusamus aspernatur quo aperiam et.\"}',13,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(5,'{\"en\":\"Unde consequatur et soluta deserunt illo.\"}',8,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(6,'{\"en\":\"Nam ipsa doloremque qui sit excepturi nulla earum.\"}',1,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(7,'{\"en\":\"Quae enim delectus aspernatur quidem id non vel.\"}',1,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(8,'{\"en\":\"Nesciunt ut mollitia commodi sint quis porro.\"}',11,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(9,'{\"en\":\"Earum veritatis quos debitis assumenda laudantium.\"}',10,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(10,'{\"en\":\"Commodi perspiciatis ut rerum quaerat dolorum.\"}',3,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(11,'{\"en\":\"Numquam corporis sit quia explicabo autem temporibus ipsum.\"}',5,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(12,'{\"en\":\"Iste qui nulla voluptate consequatur in quo ad.\"}',5,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(13,'{\"en\":\"Accusantium rerum magnam numquam commodi optio aut.\"}',17,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(14,'{\"en\":\"Cumque aperiam voluptas aut saepe voluptas est in.\"}',7,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(15,'{\"en\":\"Ut sapiente officiis dolore aliquam.\"}',16,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(16,'{\"en\":\"Debitis consequatur aperiam voluptas aut dicta omnis.\"}',11,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(17,'{\"en\":\"Vel corrupti vel architecto dolor dicta.\"}',17,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(18,'{\"en\":\"Voluptas rem reiciendis incidunt voluptatem voluptatem repudiandae vel.\"}',13,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(19,'{\"en\":\"Ea quod consectetur error commodi inventore in qui.\"}',2,'2022-05-17 07:26:18','2022-05-17 07:26:18'),(20,'{\"en\":\"Itaque voluptate et sed dolorum qui at quia.\"}',5,'2022-05-17 07:26:18','2022-05-17 07:26:18');
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_apply`
--

DROP TABLE IF EXISTS `job_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_apply` (
  `job_apply_id` int(10) NOT NULL AUTO_INCREMENT,
  `job_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `apply_status` varchar(20) NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`job_apply_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_apply`
--

LOCK TABLES `job_apply` WRITE;
/*!40000 ALTER TABLE `job_apply` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `collection_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `manipulations` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_properties` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsive_images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_column` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` (`id`, `model_type`, `model_id`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `size`, `manipulations`, `custom_properties`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES (3,'App\\Models\\PaymentMethod',2,'logo','razorpay','razorpay.png','image/png','public',13026,'[]','{\"uuid\":\"13e62475-6b5f-4812-b484-2b94cc52b715\",\"user_id\":1,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',3,'2021-05-07 12:33:38','2021-05-07 12:33:38'),(5,'App\\Models\\PaymentMethod',5,'logo','paypal','paypal.png','image/png','public',15819,'[]','{\"uuid\":\"2b8bd9b8-5c37-4464-a5c7-623496d7655f\",\"user_id\":1,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',5,'2021-05-07 12:33:49','2021-05-07 12:33:49'),(7,'App\\Models\\PaymentMethod',6,'logo','pay_pickup','pay_pickup.png','image/png','public',11712,'[]','{\"uuid\":\"5e06e7ca-ac33-413c-9ab0-6fd4e3083cc1\",\"user_id\":1,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',7,'2021-05-07 12:33:58','2021-05-07 12:33:58'),(9,'App\\Models\\PaymentMethod',7,'logo','stripe-logo','stripe-logo.png','image/png','public',5436,'[]','{\"uuid\":\"bd448a36-8a5e-4c85-8d6e-c356843429c8\",\"user_id\":1,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',9,'2021-05-07 12:34:23','2021-05-07 12:34:23'),(10,'App\\Models\\PaymentMethod',9,'logo','flutterwave','flutterwave.png','image/png','public',5436,'[]','{\"uuid\":\"bd558a96-8a5e-4a85-8d6e-c456648429c8\",\"user_id\":1,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',10,'2021-05-07 12:34:23','2021-05-07 12:34:23'),(11,'App\\Models\\PaymentMethod',8,'logo','paystack','paystack.png','image/png','public',5436,'[]','{\"uuid\":\"bd448a96-8a5e-4c85-8d6e-c356648429c8\",\"user_id\":1,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',11,'2021-05-07 12:34:23','2021-05-07 12:34:23'),(12,'App\\Models\\PaymentMethod',10,'logo','fpx','fpx.png','image/png','public',5436,'[]','{\"uuid\":\"bd558a84-8a5e-4b85-8d6f-c456648429c8\",\"user_id\":1,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',12,'2021-05-07 12:34:23','2021-05-07 12:34:23'),(13,'App\\Models\\PaymentMethod',11,'logo','wallet','wallet.png','image/png','public',5436,'[]','{\"uuid\":\"bd558a84-8a5e-4b85-8d6f-c456648429c8\",\"user_id\":1,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',12,'2021-05-07 12:34:23','2021-05-07 12:34:23'),(14,'App\\Models\\PaymentMethod',12,'logo','paymongo','paymongo.png','image/png','public',5436,'[]','{\"uuid\":\"bd558a84-8a5e-4b85-8d6f-c456648429c8\",\"user_id\":1,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',12,'2021-05-07 12:34:23','2021-05-07 12:34:23'),(15,'App\\Models\\Upload',1,'image','scaled_image_picker3754521354079762473','scaled_image_picker3754521354079762473.jpg','image/jpeg','public',5855,'[]','{\"uuid\":\"66c92ec2-359a-4ec6-8803-a7212162af7d\",\"user_id\":11,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',13,'2022-05-19 07:24:00','2022-05-19 07:24:01'),(16,'App\\Models\\Upload',2,'image','scaled_image_picker6919730081103279869','scaled_image_picker6919730081103279869.jpg','image/jpeg','public',5855,'[]','{\"uuid\":\"cc837abf-ebb6-429c-8df9-5a34b33d34b3\",\"user_id\":11,\"generated_conversions\":{\"thumb\":true,\"icon\":true}}','[]',14,'2022-05-19 08:10:11','2022-05-19 08:10:12');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_05_26_175145_create_permission_tables',1),(4,'2018_06_12_140344_create_media_table',1),(5,'2018_06_13_035117_create_uploads_table',1),(6,'2018_07_17_180731_create_settings_table',1),(7,'2018_07_24_211308_create_custom_fields_table',1),(8,'2018_07_24_211327_create_custom_field_values_table',1),(9,'2019_08_19_000000_create_failed_jobs_table',1),(10,'2019_08_29_213829_create_faq_categories_table',1),(11,'2019_08_29_213926_create_faqs_table',1),(12,'2019_10_22_144652_create_currencies_table',1),(13,'2021_01_07_162658_create_payment_methods_table',1),(14,'2021_01_07_164755_create_payment_statuses_table',1),(15,'2021_01_07_165422_create_payments_table',1),(16,'2021_01_13_105605_create_e_provider_types_table',1),(17,'2021_01_13_111155_create_e_providers_table',1),(18,'2021_01_13_111622_create_experiences_table',1),(19,'2021_01_13_111730_create_awards_table',1),(20,'2021_01_13_114302_create_taxes_table',1),(21,'2021_01_13_200249_create_addresses_table',1),(22,'2021_01_15_115239_create_e_provider_addresses_table',1),(23,'2021_01_15_115747_create_e_provider_users_table',1),(24,'2021_01_15_115850_create_e_provider_taxes_table',1),(25,'2021_01_16_160838_create_availability_hours_table',1),(26,'2021_01_19_135951_create_e_services_table',1),(27,'2021_01_19_140427_create_categories_table',1),(28,'2021_01_19_171553_create_e_service_categories_table',1),(29,'2021_01_22_194514_create_option_groups_table',1),(30,'2021_01_22_200807_create_options_table',1),(31,'2021_01_22_205819_create_favorites_table',1),(32,'2021_01_22_205944_create_favorite_options_table',1),(33,'2021_01_23_125641_create_e_service_reviews_table',1),(34,'2021_01_23_201533_create_galleries_table',1),(35,'2021_01_25_105421_create_slides_table',1),(36,'2021_01_25_162055_create_notifications_table',1),(37,'2021_01_25_170522_create_coupons_table',1),(38,'2021_01_25_170529_create_discountables_table',1),(39,'2021_01_25_191833_create_booking_statuses_table',1),(40,'2021_01_25_212252_create_bookings_table',1),(41,'2021_01_30_111717_create_e_provider_payouts_table',1),(42,'2021_01_30_135356_create_earnings_table',1),(43,'2021_02_24_102838_create_custom_pages_table',1),(44,'2021_06_26_110636_create_json_extract_function',1),(45,'2021_08_08_134136_create_wallets_table',1),(46,'2021_08_08_155732_create_wallet_transactions_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES (2,'App\\Models\\User',1),(3,'App\\Models\\User',2),(4,'App\\Models\\User',3),(3,'App\\Models\\User',4),(4,'App\\Models\\User',5),(3,'App\\Models\\User',6),(4,'App\\Models\\User',7),(4,'App\\Models\\User',8),(4,'App\\Models\\User',9),(4,'App\\Models\\User',10),(4,'App\\Models\\User',11);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES ('31c7f0ba-5ec2-4fa4-af13-9f0512935625','App\\Notifications\\NewMessage','App\\Models\\User',4,'{\"from\":\"Jennifer Paul\",\"message_id\":\"[#cd60d]\"}',NULL,'2022-05-18 09:13:38','2022-05-18 09:13:38'),('368d6380-05c6-46ed-aa38-61858fd056da','App\\Notifications\\NewMessage','App\\Models\\User',7,'{\"from\":\"Jennifer Paul\",\"message_id\":\"[#b1f8e]\"}',NULL,'2022-05-18 09:14:09','2022-05-18 09:14:09'),('4cf7d57e-ac0a-4031-ac0b-4dee3d045ba5','App\\Notifications\\NewMessage','App\\Models\\User',4,'{\"from\":\"Jennifer Paul\",\"message_id\":\"[#f9391]\"}',NULL,'2022-05-18 09:14:11','2022-05-18 09:14:11'),('6c1320eb-c4f5-4453-bda3-93a132c9c544','App\\Notifications\\NewMessage','App\\Models\\User',4,'{\"from\":\"Jennifer Paul\",\"message_id\":\"[#b1f8e]\"}',NULL,'2022-05-18 09:14:39','2022-05-18 09:14:39'),('96451a0c-43b7-4417-8d30-35d14c5e5f0a','App\\Notifications\\NewMessage','App\\Models\\User',4,'{\"from\":\"Jennifer Paul\",\"message_id\":\"[#b1f8e]\"}',NULL,'2022-05-18 09:14:09','2022-05-18 09:14:09'),('a4611d10-46cb-4297-a2a6-dd20c8053cc1','App\\Notifications\\NewMessage','App\\Models\\User',4,'{\"from\":\"Jennifer Paul\",\"message_id\":\"[#cd60d]\"}',NULL,'2022-05-18 09:13:19','2022-05-18 09:13:19'),('a84994d3-a34e-4e94-b1b5-294ff3f66b12','App\\Notifications\\NewMessage','App\\Models\\User',4,'{\"from\":\"Jennifer Paul\",\"message_id\":\"[#b1f8e]\"}',NULL,'2022-05-18 09:14:33','2022-05-18 09:14:33'),('cc34ccbf-a455-4895-b06e-c41b6b954f48','App\\Notifications\\NewMessage','App\\Models\\User',7,'{\"from\":\"Jennifer Paul\",\"message_id\":\"[#b1f8e]\"}',NULL,'2022-05-18 09:14:40','2022-05-18 09:14:40'),('f3d5b70c-3e89-41e3-96a0-9adb98d49723','App\\Notifications\\NewMessage','App\\Models\\User',7,'{\"from\":\"Jennifer Paul\",\"message_id\":\"[#b1f8e]\"}',NULL,'2022-05-18 09:14:33','2022-05-18 09:14:33');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `option_groups`
--

DROP TABLE IF EXISTS `option_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `option_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_ci,
  `allow_multiple` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `option_groups`
--

LOCK TABLES `option_groups` WRITE;
/*!40000 ALTER TABLE `option_groups` DISABLE KEYS */;
INSERT INTO `option_groups` (`id`, `name`, `allow_multiple`, `created_at`, `updated_at`) VALUES (1,'Size',1,'2021-01-22 14:19:15','2021-02-07 15:00:19'),(2,'Area',1,'2021-01-22 15:16:28','2021-01-22 15:16:28'),(3,'Surface',0,'2021-01-22 15:16:47','2021-01-22 15:16:47');
/*!40000 ALTER TABLE `option_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_ci,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `price` double(10,2) NOT NULL DEFAULT '0.00',
  `e_service_id` int(10) unsigned NOT NULL,
  `option_group_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `options_e_service_id_foreign` (`e_service_id`),
  KEY `options_option_group_id_foreign` (`option_group_id`),
  CONSTRAINT `options_e_service_id_foreign` FOREIGN KEY (`e_service_id`) REFERENCES `e_services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `options_option_group_id_foreign` FOREIGN KEY (`option_group_id`) REFERENCES `option_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` (`id`, `name`, `description`, `price`, `e_service_id`, `option_group_id`, `created_at`, `updated_at`) VALUES (1,'{\"en\":\"10m²\"}','{\"en\":\"Nisi ut itaque.\"}',37.36,20,3,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(2,'{\"en\":\"20m\"}','{\"en\":\"Deleniti alias autem numquam adipisci aut.\"}',42.15,20,3,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(3,'{\"en\":\"30m²\"}','{\"en\":\"Omnis et aperiam eum repudiandae et.\"}',38.79,10,2,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(4,'{\"en\":\"10m²\"}','{\"en\":\"Iusto qui officiis.\"}',46.34,7,1,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(5,'{\"en\":\"10m²\"}','{\"en\":\"Maiores et reiciendis.\"}',20.70,40,1,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(6,'{\"en\":\"30m²\"}','{\"en\":\"Perspiciatis voluptatum illo eius praesentium.\"}',43.53,38,2,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(7,'{\"en\":\"20m\"}','{\"en\":\"Doloribus quo dolor quasi.\"}',11.67,40,1,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(8,'{\"en\":\"40m\"}','{\"en\":\"Accusamus suscipit velit nam.\"}',23.75,4,2,'2022-05-17 07:26:20','2022-05-17 07:26:20'),(9,'{\"en\":\"30m²\"}','{\"en\":\"Similique ducimus sed.\"}',11.66,24,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(10,'{\"en\":\"30m²\"}','{\"en\":\"Qui expedita rerum explicabo ut.\"}',36.64,20,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(11,'{\"en\":\"20m\"}','{\"en\":\"Et est consequatur voluptates exercitationem.\"}',43.71,38,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(12,'{\"en\":\"30m²\"}','{\"en\":\"Earum voluptatem inventore.\"}',34.71,25,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(13,'{\"en\":\"10m²\"}','{\"en\":\"Velit ea et voluptatum odio.\"}',43.05,40,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(14,'{\"en\":\"20m\"}','{\"en\":\"Numquam voluptas adipisci est.\"}',39.62,3,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(15,'{\"en\":\"20m\"}','{\"en\":\"Voluptate illum repellendus quia.\"}',12.26,18,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(16,'{\"en\":\"10m²\"}','{\"en\":\"Voluptas rerum corrupti quos.\"}',27.84,14,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(17,'{\"en\":\"40m\"}','{\"en\":\"Voluptate id similique.\"}',16.02,1,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(18,'{\"en\":\"10m²\"}','{\"en\":\"Aperiam recusandae facere quae.\"}',27.25,13,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(19,'{\"en\":\"10m²\"}','{\"en\":\"Consequatur in repellat et id.\"}',39.91,15,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(20,'{\"en\":\"30m²\"}','{\"en\":\"Distinctio tempora aperiam pariatur aut.\"}',46.21,19,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(21,'{\"en\":\"20m\"}','{\"en\":\"Debitis eos eos ut adipisci.\"}',23.30,8,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(22,'{\"en\":\"20m\"}','{\"en\":\"Laboriosam voluptas repellat maiores earum.\"}',29.21,1,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(23,'{\"en\":\"10m²\"}','{\"en\":\"Aperiam dolorem sequi vero.\"}',28.27,36,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(24,'{\"en\":\"10m²\"}','{\"en\":\"Corrupti eos quo beatae aut.\"}',36.84,37,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(25,'{\"en\":\"10m²\"}','{\"en\":\"Odio quo aut odio et.\"}',37.73,19,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(26,'{\"en\":\"40m\"}','{\"en\":\"Illum libero voluptatem deleniti reprehenderit.\"}',35.04,21,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(27,'{\"en\":\"20m\"}','{\"en\":\"Est suscipit aut eius.\"}',12.31,23,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(28,'{\"en\":\"20m\"}','{\"en\":\"Ut quasi blanditiis ut officiis qui.\"}',42.69,27,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(29,'{\"en\":\"40m\"}','{\"en\":\"Adipisci ut in debitis debitis voluptatem.\"}',48.73,36,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(30,'{\"en\":\"20m\"}','{\"en\":\"Rem alias odio.\"}',20.67,29,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(31,'{\"en\":\"40m\"}','{\"en\":\"Sint quam dolor sunt.\"}',21.27,29,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(32,'{\"en\":\"40m\"}','{\"en\":\"Corrupti error numquam.\"}',14.29,25,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(33,'{\"en\":\"40m\"}','{\"en\":\"Et ut dolores vitae.\"}',19.73,37,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(34,'{\"en\":\"10m²\"}','{\"en\":\"Velit dicta eveniet tempore est.\"}',32.80,13,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(35,'{\"en\":\"30m²\"}','{\"en\":\"Expedita totam consectetur debitis.\"}',41.14,28,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(36,'{\"en\":\"10m²\"}','{\"en\":\"A voluptatem odit nobis eum.\"}',11.13,32,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(37,'{\"en\":\"10m²\"}','{\"en\":\"Aut aut quam ipsum.\"}',43.21,30,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(38,'{\"en\":\"30m²\"}','{\"en\":\"Vel qui aut consectetur dignissimos sint.\"}',44.45,12,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(39,'{\"en\":\"10m²\"}','{\"en\":\"Deserunt amet reprehenderit sint itaque.\"}',28.03,30,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(40,'{\"en\":\"30m²\"}','{\"en\":\"Accusantium ad omnis fuga.\"}',35.32,21,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(41,'{\"en\":\"10m²\"}','{\"en\":\"Quis sunt impedit qui.\"}',47.76,30,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(42,'{\"en\":\"10m²\"}','{\"en\":\"Distinctio molestiae qui veniam aut et.\"}',29.11,39,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(43,'{\"en\":\"20m\"}','{\"en\":\"Unde voluptas doloribus nemo excepturi.\"}',41.33,18,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(44,'{\"en\":\"40m\"}','{\"en\":\"Alias repellat expedita.\"}',24.07,2,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(45,'{\"en\":\"30m²\"}','{\"en\":\"Voluptate sint voluptatem.\"}',39.48,24,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(46,'{\"en\":\"30m²\"}','{\"en\":\"Quis sed nobis.\"}',26.04,13,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(47,'{\"en\":\"40m\"}','{\"en\":\"Molestiae a eaque dolorem.\"}',19.52,33,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(48,'{\"en\":\"30m²\"}','{\"en\":\"Cum animi magnam ullam sed.\"}',10.90,3,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(49,'{\"en\":\"30m²\"}','{\"en\":\"Quia magnam perferendis odio.\"}',36.38,9,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(50,'{\"en\":\"30m²\"}','{\"en\":\"Rem et voluptatem voluptas omnis.\"}',36.06,28,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(51,'{\"en\":\"30m²\"}','{\"en\":\"Ut natus officiis consequatur dolore.\"}',33.75,35,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(52,'{\"en\":\"30m²\"}','{\"en\":\"Quae accusantium consequatur.\"}',12.88,34,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(53,'{\"en\":\"10m²\"}','{\"en\":\"Voluptatibus ea eligendi vitae.\"}',19.35,16,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(54,'{\"en\":\"40m\"}','{\"en\":\"Vero molestiae minus est velit.\"}',15.26,1,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(55,'{\"en\":\"30m²\"}','{\"en\":\"Illum sint et omnis.\"}',20.44,2,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(56,'{\"en\":\"10m²\"}','{\"en\":\"Laborum rerum est sit.\"}',40.66,29,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(57,'{\"en\":\"20m\"}','{\"en\":\"Esse ex saepe eos voluptate.\"}',18.82,36,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(58,'{\"en\":\"10m²\"}','{\"en\":\"Aut et vel.\"}',34.45,12,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(59,'{\"en\":\"40m\"}','{\"en\":\"Reiciendis qui qui et occaecati doloremque.\"}',30.74,40,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(60,'{\"en\":\"30m²\"}','{\"en\":\"Qui non voluptatem officia.\"}',27.41,30,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(61,'{\"en\":\"10m²\"}','{\"en\":\"Provident quaerat ipsum nisi.\"}',14.77,24,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(62,'{\"en\":\"30m²\"}','{\"en\":\"Qui laboriosam est repellat accusamus consequatur.\"}',14.64,30,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(63,'{\"en\":\"10m²\"}','{\"en\":\"Deleniti harum vel sed.\"}',22.13,7,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(64,'{\"en\":\"40m\"}','{\"en\":\"Omnis veritatis quisquam ex molestiae repellat.\"}',22.82,16,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(65,'{\"en\":\"10m²\"}','{\"en\":\"Eaque ducimus aliquam sit molestiae.\"}',43.75,38,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(66,'{\"en\":\"30m²\"}','{\"en\":\"Et consequatur aut corporis quae.\"}',20.47,3,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(67,'{\"en\":\"40m\"}','{\"en\":\"Sed animi sit ut cumque.\"}',36.57,24,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(68,'{\"en\":\"20m\"}','{\"en\":\"Quo mollitia accusamus et delectus.\"}',33.44,35,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(69,'{\"en\":\"30m²\"}','{\"en\":\"Eaque expedita quia non.\"}',38.16,35,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(70,'{\"en\":\"30m²\"}','{\"en\":\"Blanditiis quibusdam vitae soluta numquam qui.\"}',35.42,8,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(71,'{\"en\":\"10m²\"}','{\"en\":\"Autem dolorem quasi maiores et autem.\"}',42.70,32,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(72,'{\"en\":\"30m²\"}','{\"en\":\"Earum rerum cumque dicta.\"}',46.60,4,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(73,'{\"en\":\"20m\"}','{\"en\":\"Distinctio earum sunt necessitatibus libero.\"}',19.86,16,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(74,'{\"en\":\"40m\"}','{\"en\":\"Ipsum ullam totam et eos velit.\"}',24.88,26,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(75,'{\"en\":\"40m\"}','{\"en\":\"Ut alias aut eaque.\"}',39.75,12,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(76,'{\"en\":\"30m²\"}','{\"en\":\"Aut et magnam hic omnis.\"}',45.88,31,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(77,'{\"en\":\"40m\"}','{\"en\":\"Ipsum sed maxime.\"}',31.15,16,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(78,'{\"en\":\"10m²\"}','{\"en\":\"Eos quibusdam delectus id.\"}',34.51,2,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(79,'{\"en\":\"30m²\"}','{\"en\":\"Numquam accusantium voluptate.\"}',13.18,33,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(80,'{\"en\":\"30m²\"}','{\"en\":\"Libero eius harum sed.\"}',19.42,16,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(81,'{\"en\":\"40m\"}','{\"en\":\"Rerum alias sit.\"}',13.34,7,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(82,'{\"en\":\"10m²\"}','{\"en\":\"Qui animi velit debitis.\"}',39.25,1,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(83,'{\"en\":\"40m\"}','{\"en\":\"Aut nam aspernatur libero sed ipsum.\"}',17.76,19,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(84,'{\"en\":\"10m²\"}','{\"en\":\"Odit esse neque ut nisi.\"}',38.23,10,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(85,'{\"en\":\"30m²\"}','{\"en\":\"Illum rerum repellendus.\"}',32.94,6,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(86,'{\"en\":\"30m²\"}','{\"en\":\"Amet quos itaque.\"}',31.61,19,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(87,'{\"en\":\"20m\"}','{\"en\":\"Praesentium eveniet ipsa est in.\"}',25.45,25,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(88,'{\"en\":\"30m²\"}','{\"en\":\"Minus placeat officiis maiores quia vel.\"}',26.63,39,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(89,'{\"en\":\"40m\"}','{\"en\":\"Ut suscipit nisi unde ut.\"}',31.95,11,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(90,'{\"en\":\"30m²\"}','{\"en\":\"Delectus sequi voluptatem hic voluptas.\"}',48.68,25,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(91,'{\"en\":\"40m\"}','{\"en\":\"Expedita quo illum quasi.\"}',38.14,18,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(92,'{\"en\":\"30m²\"}','{\"en\":\"Similique iusto modi dolorum delectus alias.\"}',42.29,39,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(93,'{\"en\":\"10m²\"}','{\"en\":\"Qui repellendus tenetur minus aperiam.\"}',19.95,14,2,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(94,'{\"en\":\"10m²\"}','{\"en\":\"Est exercitationem cumque.\"}',16.17,3,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(95,'{\"en\":\"20m\"}','{\"en\":\"Voluptas rem sit autem aut nesciunt.\"}',49.67,24,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(96,'{\"en\":\"40m\"}','{\"en\":\"Velit consequatur ut.\"}',20.85,37,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(97,'{\"en\":\"30m²\"}','{\"en\":\"Quia fuga possimus ut.\"}',40.87,22,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(98,'{\"en\":\"30m²\"}','{\"en\":\"Quasi quo molestiae accusantium.\"}',16.91,1,1,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(99,'{\"en\":\"10m²\"}','{\"en\":\"Molestias necessitatibus sunt.\"}',18.57,2,3,'2022-05-17 07:26:21','2022-05-17 07:26:21'),(100,'{\"en\":\"40m\"}','{\"en\":\"Nulla ea et illo dolorem.\"}',17.44,40,1,'2022-05-17 07:26:21','2022-05-17 07:26:21');
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_methods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_ci,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `route` varchar(127) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '0',
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` (`id`, `name`, `description`, `route`, `order`, `default`, `enabled`, `created_at`, `updated_at`) VALUES (2,'RazorPay','Click to pay with RazorPay gateway','/RazorPay',2,0,1,'2021-01-17 09:03:49','2021-02-17 17:07:30'),(5,'PayPal','Click to pay with your PayPal account','/PayPal',1,0,1,'2021-01-17 10:16:06','2021-02-17 17:08:47'),(6,'Cash','Click to pay cash when finish','/Cash',3,1,1,'2021-02-17 17:08:42','2021-02-17 17:08:42'),(7,'Credit Card (Stripe)','Click to pay with your Credit Card','/Stripe',3,0,1,'2021-02-17 17:08:42','2021-02-17 17:08:42'),(8,'PayStack','Click to pay with PayStack gateway','/PayStack',5,0,1,'2021-07-23 17:08:42','2021-07-23 17:08:42'),(9,'FlutterWave','Click to pay with FlutterWave gateway','/FlutterWave',6,0,1,'2021-07-23 17:08:42','2021-07-23 17:08:42'),(10,'Malaysian Stripe FPX	','Click to pay with Stripe FPX gateway','/StripeFPX',7,0,1,'2021-07-24 17:08:42','2021-07-24 17:08:42'),(11,'Wallet','Click to pay with Wallet','/Wallet',8,0,1,'2021-08-08 17:08:42','2021-08-08 17:08:42'),(12,'PayMongo','Click to pay with PayMongo','/PayMongo',12,0,1,'2021-10-08 17:08:42','2021-10-08 17:08:42');
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_statuses`
--

DROP TABLE IF EXISTS `payment_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` longtext COLLATE utf8mb4_unicode_ci,
  `order` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_statuses`
--

LOCK TABLES `payment_statuses` WRITE;
/*!40000 ALTER TABLE `payment_statuses` DISABLE KEYS */;
INSERT INTO `payment_statuses` (`id`, `status`, `order`, `created_at`, `updated_at`) VALUES (1,'Pending',1,'2021-01-17 09:58:28','2021-02-17 16:25:15'),(2,'Paid',10,'2021-01-11 17:49:49','2021-02-17 16:25:53'),(3,'Failed',20,'2021-01-17 08:35:04','2021-02-17 16:26:32'),(4,'Refunded',40,'2021-02-17 16:28:14','2021-02-17 16:28:14');
/*!40000 ALTER TABLE `payment_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amount` double(10,2) NOT NULL DEFAULT '0.00',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `payment_method_id` int(10) unsigned NOT NULL,
  `payment_status_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_user_id_foreign` (`user_id`),
  KEY `payments_payment_method_id_foreign` (`payment_method_id`),
  KEY `payments_payment_status_id_foreign` (`payment_status_id`),
  CONSTRAINT `payments_payment_method_id_foreign` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_payment_status_id_foreign` FOREIGN KEY (`payment_status_id`) REFERENCES `payment_statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES (1,'dashboard','web','2021-01-07 07:47:34','2021-01-07 07:47:34'),(2,'medias.create','web','2021-01-07 07:47:35','2021-01-07 07:47:35'),(3,'users.profile','web','2021-01-07 07:47:35','2021-01-07 07:47:35'),(4,'users.index','web','2021-01-07 07:47:35','2021-01-07 07:47:35'),(5,'users.create','web','2021-01-07 07:47:35','2021-01-07 07:47:35'),(6,'users.store','web','2021-01-07 07:47:35','2021-01-07 07:47:35'),(7,'users.show','web','2021-01-07 07:47:35','2021-01-07 07:47:35'),(8,'users.edit','web','2021-01-07 07:47:36','2021-01-07 07:47:36'),(9,'users.update','web','2021-01-07 07:47:36','2021-01-07 07:47:36'),(10,'users.destroy','web','2021-01-07 07:47:36','2021-01-07 07:47:36'),(11,'medias.delete','web','2021-01-07 07:47:36','2021-01-07 07:47:36'),(12,'medias','web','2021-01-07 07:47:36','2021-01-07 07:47:36'),(13,'permissions.index','web','2021-01-07 07:47:36','2021-01-07 07:47:36'),(14,'permissions.create','web','2021-01-07 07:47:36','2021-01-07 07:47:36'),(15,'permissions.store','web','2021-01-07 07:47:36','2021-01-07 07:47:36'),(16,'permissions.show','web','2021-01-07 07:47:37','2021-01-07 07:47:37'),(17,'permissions.edit','web','2021-01-07 07:47:37','2021-01-07 07:47:37'),(18,'permissions.update','web','2021-01-07 07:47:37','2021-01-07 07:47:37'),(19,'permissions.destroy','web','2021-01-07 07:47:37','2021-01-07 07:47:37'),(20,'roles.index','web','2021-01-07 07:47:37','2021-01-07 07:47:37'),(21,'roles.create','web','2021-01-07 07:47:37','2021-01-07 07:47:37'),(22,'roles.store','web','2021-01-07 07:47:37','2021-01-07 07:47:37'),(23,'roles.show','web','2021-01-07 07:47:38','2021-01-07 07:47:38'),(24,'roles.edit','web','2021-01-07 07:47:38','2021-01-07 07:47:38'),(25,'roles.update','web','2021-01-07 07:47:38','2021-01-07 07:47:38'),(26,'roles.destroy','web','2021-01-07 07:47:38','2021-01-07 07:47:38'),(27,'customFields.index','web','2021-01-07 07:47:38','2021-01-07 07:47:38'),(28,'customFields.create','web','2021-01-07 07:47:38','2021-01-07 07:47:38'),(29,'customFields.store','web','2021-01-07 07:47:38','2021-01-07 07:47:38'),(30,'customFields.show','web','2021-01-07 07:47:38','2021-01-07 07:47:38'),(31,'customFields.edit','web','2021-01-07 07:47:39','2021-01-07 07:47:39'),(32,'customFields.update','web','2021-01-07 07:47:39','2021-01-07 07:47:39'),(33,'customFields.destroy','web','2021-01-07 07:47:39','2021-01-07 07:47:39'),(34,'currencies.index','web','2021-01-07 07:47:39','2021-01-07 07:47:39'),(35,'currencies.create','web','2021-01-07 07:47:39','2021-01-07 07:47:39'),(36,'currencies.store','web','2021-01-07 07:47:39','2021-01-07 07:47:39'),(37,'currencies.edit','web','2021-01-07 07:47:39','2021-01-07 07:47:39'),(38,'currencies.update','web','2021-01-07 07:47:40','2021-01-07 07:47:40'),(39,'currencies.destroy','web','2021-01-07 07:47:40','2021-01-07 07:47:40'),(40,'users.login-as-user','web','2021-01-07 07:47:40','2021-01-07 07:47:40'),(41,'app-settings','web','2021-01-07 07:47:40','2021-01-07 07:47:40'),(42,'faqCategories.index','web','2021-01-07 07:47:40','2021-01-07 07:47:40'),(43,'faqCategories.create','web','2021-01-07 07:47:40','2021-01-07 07:47:40'),(44,'faqCategories.store','web','2021-01-07 07:47:40','2021-01-07 07:47:40'),(45,'faqCategories.edit','web','2021-01-07 07:47:41','2021-01-07 07:47:41'),(46,'faqCategories.update','web','2021-01-07 07:47:41','2021-01-07 07:47:41'),(47,'faqCategories.destroy','web','2021-01-07 07:47:41','2021-01-07 07:47:41'),(48,'faqs.index','web','2021-01-07 07:47:41','2021-01-07 07:47:41'),(49,'faqs.create','web','2021-01-07 07:47:41','2021-01-07 07:47:41'),(50,'faqs.store','web','2021-01-07 07:47:41','2021-01-07 07:47:41'),(51,'faqs.edit','web','2021-01-07 07:47:41','2021-01-07 07:47:41'),(52,'faqs.update','web','2021-01-07 07:47:42','2021-01-07 07:47:42'),(53,'faqs.destroy','web','2021-01-07 07:47:42','2021-01-07 07:47:42'),(54,'payments.index','web','2021-01-10 18:34:33','2021-01-10 18:34:33'),(55,'payments.show','web','2021-01-10 18:34:33','2021-01-10 18:34:33'),(56,'payments.update','web','2021-01-10 18:34:33','2021-01-10 18:34:33'),(57,'paymentMethods.index','web','2021-01-10 18:34:33','2021-01-10 18:34:33'),(58,'paymentMethods.create','web','2021-01-10 18:34:34','2021-01-10 18:34:34'),(59,'paymentMethods.store','web','2021-01-10 18:34:34','2021-01-10 18:34:34'),(60,'paymentMethods.edit','web','2021-01-10 18:34:34','2021-01-10 18:34:34'),(61,'paymentMethods.update','web','2021-01-10 18:34:34','2021-01-10 18:34:34'),(62,'paymentMethods.destroy','web','2021-01-10 18:34:34','2021-01-10 18:34:34'),(63,'paymentStatuses.index','web','2021-01-10 18:34:34','2021-01-10 18:34:34'),(64,'paymentStatuses.create','web','2021-01-10 18:34:34','2021-01-10 18:34:34'),(65,'paymentStatuses.store','web','2021-01-10 18:34:35','2021-01-10 18:34:35'),(66,'paymentStatuses.edit','web','2021-01-10 18:34:35','2021-01-10 18:34:35'),(67,'paymentStatuses.update','web','2021-01-10 18:34:35','2021-01-10 18:34:35'),(68,'paymentStatuses.destroy','web','2021-01-10 18:34:35','2021-01-10 18:34:35'),(69,'verification.notice','web','2021-01-12 04:49:50','2021-01-12 04:49:50'),(70,'verification.verify','web','2021-01-12 04:49:50','2021-01-12 04:49:50'),(71,'verification.resend','web','2021-01-12 04:49:51','2021-01-12 04:49:51'),(72,'awards.index','web','2021-01-12 04:49:51','2021-01-12 04:49:51'),(73,'awards.create','web','2021-01-12 04:49:52','2021-01-12 04:49:52'),(74,'awards.store','web','2021-01-12 04:49:52','2021-01-12 04:49:52'),(75,'awards.show','web','2021-01-12 04:49:52','2021-01-12 04:49:52'),(76,'awards.edit','web','2021-01-12 04:49:52','2021-01-12 04:49:52'),(77,'awards.update','web','2021-01-12 04:49:52','2021-01-12 04:49:52'),(78,'awards.destroy','web','2021-01-12 04:49:52','2021-01-12 04:49:52'),(79,'experiences.index','web','2021-01-12 05:50:29','2021-01-12 05:50:29'),(80,'experiences.create','web','2021-01-12 05:50:29','2021-01-12 05:50:29'),(81,'experiences.store','web','2021-01-12 05:50:30','2021-01-12 05:50:30'),(82,'experiences.show','web','2021-01-12 05:50:30','2021-01-12 05:50:30'),(83,'experiences.edit','web','2021-01-12 05:50:30','2021-01-12 05:50:30'),(84,'experiences.update','web','2021-01-12 05:50:30','2021-01-12 05:50:30'),(85,'experiences.destroy','web','2021-01-12 05:50:30','2021-01-12 05:50:30'),(92,'eProviderTypes.index','web','2021-01-13 06:01:08','2021-01-13 06:01:08'),(93,'eProviderTypes.create','web','2021-01-13 06:01:09','2021-01-13 06:01:09'),(94,'eProviderTypes.store','web','2021-01-13 06:01:09','2021-01-13 06:01:09'),(95,'eProviderTypes.edit','web','2021-01-13 06:01:09','2021-01-13 06:01:09'),(96,'eProviderTypes.update','web','2021-01-13 06:01:09','2021-01-13 06:01:09'),(97,'eProviderTypes.destroy','web','2021-01-13 06:01:09','2021-01-13 06:01:09'),(98,'eProviders.index','web','2021-01-13 06:18:55','2021-01-13 06:18:55'),(99,'eProviders.create','web','2021-01-13 06:18:56','2021-01-13 06:18:56'),(100,'eProviders.store','web','2021-01-13 06:18:56','2021-01-13 06:18:56'),(101,'eProviders.edit','web','2021-01-13 06:18:56','2021-01-13 06:18:56'),(102,'eProviders.update','web','2021-01-13 06:18:56','2021-01-13 06:18:56'),(103,'eProviders.destroy','web','2021-01-13 06:18:56','2021-01-13 06:18:56'),(104,'addresses.index','web','2021-01-13 06:18:56','2021-01-13 06:18:56'),(105,'addresses.create','web','2021-01-13 06:18:57','2021-01-13 06:18:57'),(106,'addresses.store','web','2021-01-13 06:18:57','2021-01-13 06:18:57'),(107,'addresses.edit','web','2021-01-13 06:18:57','2021-01-13 06:18:57'),(108,'addresses.update','web','2021-01-13 06:18:57','2021-01-13 06:18:57'),(109,'addresses.destroy','web','2021-01-13 06:18:57','2021-01-13 06:18:57'),(110,'taxes.index','web','2021-01-13 06:18:57','2021-01-13 06:18:57'),(111,'taxes.create','web','2021-01-13 06:18:57','2021-01-13 06:18:57'),(112,'taxes.store','web','2021-01-13 06:18:58','2021-01-13 06:18:58'),(113,'taxes.edit','web','2021-01-13 06:18:58','2021-01-13 06:18:58'),(114,'taxes.update','web','2021-01-13 06:18:58','2021-01-13 06:18:58'),(115,'taxes.destroy','web','2021-01-13 06:18:58','2021-01-13 06:18:58'),(116,'availabilityHours.index','web','2021-01-16 10:44:21','2021-01-16 10:44:21'),(117,'availabilityHours.create','web','2021-01-16 10:44:21','2021-01-16 10:44:21'),(118,'availabilityHours.store','web','2021-01-16 10:44:21','2021-01-16 10:44:21'),(119,'availabilityHours.edit','web','2021-01-16 10:44:21','2021-01-16 10:44:21'),(120,'availabilityHours.update','web','2021-01-16 10:44:22','2021-01-16 10:44:22'),(121,'availabilityHours.destroy','web','2021-01-16 10:44:22','2021-01-16 10:44:22'),(122,'eServices.index','web','2021-01-19 08:33:00','2021-01-19 08:33:00'),(123,'eServices.create','web','2021-01-19 08:33:00','2021-01-19 08:33:00'),(124,'eServices.store','web','2021-01-19 08:33:00','2021-01-19 08:33:00'),(126,'eServices.edit','web','2021-01-19 08:33:01','2021-01-19 08:33:01'),(127,'eServices.update','web','2021-01-19 08:33:01','2021-01-19 08:33:01'),(128,'eServices.destroy','web','2021-01-19 08:33:01','2021-01-19 08:33:01'),(129,'categories.index','web','2021-01-19 08:38:55','2021-01-19 08:38:55'),(130,'categories.create','web','2021-01-19 08:38:55','2021-01-19 08:38:55'),(131,'categories.store','web','2021-01-19 08:38:55','2021-01-19 08:38:55'),(132,'categories.edit','web','2021-01-19 08:38:55','2021-01-19 08:38:55'),(133,'categories.update','web','2021-01-19 08:38:56','2021-01-19 08:38:56'),(134,'categories.destroy','web','2021-01-19 08:38:56','2021-01-19 08:38:56'),(135,'optionGroups.index','web','2021-01-22 14:18:32','2021-01-22 14:18:32'),(136,'optionGroups.create','web','2021-01-22 14:18:32','2021-01-22 14:18:32'),(137,'optionGroups.store','web','2021-01-22 14:18:32','2021-01-22 14:18:32'),(138,'optionGroups.edit','web','2021-01-22 14:18:32','2021-01-22 14:18:32'),(139,'optionGroups.update','web','2021-01-22 14:18:32','2021-01-22 14:18:32'),(140,'optionGroups.destroy','web','2021-01-22 14:18:32','2021-01-22 14:18:32'),(141,'options.index','web','2021-01-22 14:40:51','2021-01-22 14:40:51'),(142,'options.create','web','2021-01-22 14:40:51','2021-01-22 14:40:51'),(143,'options.store','web','2021-01-22 14:40:52','2021-01-22 14:40:52'),(144,'options.edit','web','2021-01-22 14:40:52','2021-01-22 14:40:52'),(145,'options.update','web','2021-01-22 14:40:52','2021-01-22 14:40:52'),(146,'options.destroy','web','2021-01-22 14:40:52','2021-01-22 14:40:52'),(147,'favorites.index','web','2021-01-22 15:31:13','2021-01-22 15:31:13'),(148,'favorites.create','web','2021-01-22 15:31:13','2021-01-22 15:31:13'),(149,'favorites.store','web','2021-01-22 15:31:13','2021-01-22 15:31:13'),(150,'favorites.edit','web','2021-01-22 15:31:13','2021-01-22 15:31:13'),(151,'favorites.update','web','2021-01-22 15:31:13','2021-01-22 15:31:13'),(152,'favorites.destroy','web','2021-01-22 15:31:13','2021-01-22 15:31:13'),(153,'eServiceReviews.index','web','2021-01-23 14:12:57','2021-01-23 14:12:57'),(154,'eServiceReviews.create','web','2021-01-23 14:12:58','2021-01-23 14:12:58'),(155,'eServiceReviews.store','web','2021-01-23 14:12:58','2021-01-23 14:12:58'),(156,'eServiceReviews.edit','web','2021-01-23 14:12:58','2021-01-23 14:12:58'),(157,'eServiceReviews.update','web','2021-01-23 14:12:58','2021-01-23 14:12:58'),(158,'eServiceReviews.destroy','web','2021-01-23 14:12:58','2021-01-23 14:12:58'),(160,'galleries.index','web','2021-01-23 14:47:46','2021-01-23 14:47:46'),(161,'galleries.create','web','2021-01-23 14:47:47','2021-01-23 14:47:47'),(162,'galleries.store','web','2021-01-23 14:47:47','2021-01-23 14:47:47'),(163,'galleries.edit','web','2021-01-23 14:47:47','2021-01-23 14:47:47'),(164,'galleries.update','web','2021-01-23 14:47:47','2021-01-23 14:47:47'),(165,'galleries.destroy','web','2021-01-23 14:47:47','2021-01-23 14:47:47'),(166,'requestedEProviders.index','web','2021-01-25 04:23:17','2021-01-25 04:23:17'),(167,'slides.index','web','2021-01-25 05:31:20','2021-01-25 05:31:20'),(168,'slides.create','web','2021-01-25 05:31:20','2021-01-25 05:31:20'),(169,'slides.store','web','2021-01-25 05:31:20','2021-01-25 05:31:20'),(170,'slides.edit','web','2021-01-25 05:31:20','2021-01-25 05:31:20'),(171,'slides.update','web','2021-01-25 05:31:20','2021-01-25 05:31:20'),(172,'slides.destroy','web','2021-01-25 05:31:20','2021-01-25 05:31:20'),(173,'notifications.index','web','2021-01-25 10:12:33','2021-01-25 10:12:33'),(174,'notifications.show','web','2021-01-25 10:12:34','2021-01-25 10:12:34'),(175,'notifications.destroy','web','2021-01-25 10:12:34','2021-01-25 10:12:34'),(176,'coupons.index','web','2021-01-25 10:41:55','2021-01-25 10:41:55'),(177,'coupons.create','web','2021-01-25 10:41:55','2021-01-25 10:41:55'),(178,'coupons.store','web','2021-01-25 10:41:55','2021-01-25 10:41:55'),(179,'coupons.edit','web','2021-01-25 10:41:55','2021-01-25 10:41:55'),(180,'coupons.update','web','2021-01-25 10:41:55','2021-01-25 10:41:55'),(181,'coupons.destroy','web','2021-01-25 10:41:55','2021-01-25 10:41:55'),(182,'bookingStatuses.index','web','2021-01-25 13:51:01','2021-01-25 13:51:01'),(183,'bookingStatuses.create','web','2021-01-25 13:51:01','2021-01-25 13:51:01'),(184,'bookingStatuses.store','web','2021-01-25 13:51:01','2021-01-25 13:51:01'),(185,'bookingStatuses.edit','web','2021-01-25 13:51:01','2021-01-25 13:51:01'),(186,'bookingStatuses.update','web','2021-01-25 13:51:01','2021-01-25 13:51:01'),(187,'bookingStatuses.destroy','web','2021-01-25 13:51:01','2021-01-25 13:51:01'),(188,'bookings.index','web','2021-01-25 15:57:09','2021-01-25 15:57:09'),(189,'bookings.create','web','2021-01-25 15:57:09','2021-01-25 15:57:09'),(190,'bookings.store','web','2021-01-25 15:57:09','2021-01-25 15:57:09'),(191,'bookings.show','web','2021-01-25 15:57:09','2021-01-25 15:57:09'),(192,'bookings.edit','web','2021-01-25 15:57:09','2021-01-25 15:57:09'),(193,'bookings.update','web','2021-01-25 15:57:09','2021-01-25 15:57:09'),(194,'bookings.destroy','web','2021-01-25 15:57:09','2021-01-25 15:57:09'),(195,'eProviderPayouts.index','web','2021-01-30 05:53:08','2021-01-30 05:53:08'),(196,'eProviderPayouts.create','web','2021-01-30 05:53:08','2021-01-30 05:53:08'),(197,'eProviderPayouts.store','web','2021-01-30 05:53:08','2021-01-30 05:53:08'),(198,'eProviderPayouts.destroy','web','2021-01-30 05:53:09','2021-01-30 05:53:09'),(199,'earnings.index','web','2021-01-30 08:27:57','2021-01-30 08:27:57'),(200,'earnings.create','web','2021-01-30 08:27:57','2021-01-30 08:27:57'),(201,'earnings.store','web','2021-01-30 08:27:57','2021-01-30 08:27:57'),(202,'earnings.destroy','web','2021-01-30 08:27:57','2021-01-30 08:27:57'),(203,'customPages.index','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(204,'customPages.create','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(205,'customPages.store','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(206,'customPages.show','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(207,'customPages.edit','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(208,'customPages.update','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(209,'customPages.destroy','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(210,'wallets.index','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(211,'wallets.create','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(212,'wallets.store','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(213,'wallets.update','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(214,'wallets.edit','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(215,'wallets.destroy','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(216,'walletTransactions.index','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(217,'walletTransactions.create','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(218,'walletTransactions.store','web','2021-02-24 06:07:44','2021-02-24 06:07:44'),(219,'modules.update','web','2022-05-17 07:26:17','2022-05-17 07:26:17'),(220,'modules.install','web','2022-05-17 07:26:17','2022-05-17 07:26:17'),(221,'modules.index','web','2022-05-17 07:26:17','2022-05-17 07:26:17'),(222,'modules.enable','web','2022-05-17 07:26:17','2022-05-17 07:26:17');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES (1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(8,2),(9,2),(10,2),(11,2),(12,2),(13,2),(16,2),(19,2),(20,2),(27,2),(28,2),(29,2),(30,2),(31,2),(32,2),(33,2),(34,2),(35,2),(36,2),(37,2),(38,2),(39,2),(40,2),(41,2),(42,2),(43,2),(44,2),(45,2),(46,2),(47,2),(48,2),(49,2),(50,2),(51,2),(52,2),(53,2),(54,2),(57,2),(58,2),(59,2),(60,2),(61,2),(62,2),(63,2),(66,2),(67,2),(69,2),(70,2),(71,2),(72,2),(73,2),(74,2),(75,2),(76,2),(77,2),(78,2),(79,2),(80,2),(81,2),(82,2),(83,2),(84,2),(85,2),(92,2),(93,2),(94,2),(95,2),(96,2),(97,2),(98,2),(99,2),(100,2),(101,2),(102,2),(103,2),(104,2),(105,2),(106,2),(107,2),(108,2),(109,2),(110,2),(111,2),(112,2),(113,2),(114,2),(115,2),(116,2),(117,2),(118,2),(119,2),(120,2),(121,2),(122,2),(123,2),(124,2),(126,2),(127,2),(128,2),(129,2),(130,2),(131,2),(132,2),(133,2),(134,2),(135,2),(136,2),(137,2),(138,2),(139,2),(140,2),(141,2),(142,2),(143,2),(144,2),(145,2),(146,2),(147,2),(148,2),(149,2),(150,2),(151,2),(152,2),(153,2),(156,2),(157,2),(158,2),(160,2),(161,2),(162,2),(163,2),(164,2),(165,2),(166,2),(167,2),(168,2),(169,2),(170,2),(171,2),(172,2),(173,2),(174,2),(175,2),(176,2),(177,2),(178,2),(179,2),(180,2),(181,2),(182,2),(185,2),(186,2),(188,2),(191,2),(192,2),(193,2),(194,2),(195,2),(196,2),(197,2),(199,2),(200,2),(203,2),(204,2),(205,2),(206,2),(207,2),(208,2),(209,2),(210,2),(211,2),(212,2),(213,2),(214,2),(215,2),(216,2),(217,2),(218,2),(219,2),(220,2),(221,2),(222,2),(2,3),(3,3),(9,3),(11,3),(12,3),(42,3),(48,3),(54,3),(57,3),(72,3),(73,3),(74,3),(75,3),(76,3),(77,3),(78,3),(79,3),(80,3),(81,3),(82,3),(83,3),(84,3),(85,3),(92,3),(98,3),(99,3),(100,3),(101,3),(102,3),(104,3),(105,3),(106,3),(107,3),(108,3),(109,3),(116,3),(117,3),(118,3),(119,3),(120,3),(121,3),(122,3),(123,3),(124,3),(126,3),(127,3),(128,3),(129,3),(135,3),(136,3),(137,3),(141,3),(142,3),(143,3),(144,3),(145,3),(146,3),(147,3),(149,3),(151,3),(153,3),(156,3),(157,3),(160,3),(161,3),(162,3),(163,3),(164,3),(165,3),(166,3),(173,3),(175,3),(176,3),(179,3),(180,3),(182,3),(188,3),(191,3),(192,3),(193,3),(194,3),(195,3),(196,3),(197,3),(199,3),(200,3),(203,3),(210,3),(216,3),(2,4),(3,4),(9,4),(11,4),(42,4),(48,4),(54,4),(98,4),(99,4),(100,4),(104,4),(105,4),(106,4),(107,4),(108,4),(109,4),(122,4),(129,4),(147,4),(153,4),(156,4),(157,4),(166,4),(173,4),(175,4),(188,4),(191,4),(203,4),(210,4),(216,4);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `default` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`, `guard_name`, `default`, `created_at`, `updated_at`) VALUES (2,'admin','web',0,NULL,NULL),(3,'provider','web',0,NULL,NULL),(4,'customer','web',1,NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slides`
--

DROP TABLE IF EXISTS `slides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slides` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(10) unsigned DEFAULT '0',
  `text` longtext COLLATE utf8mb4_unicode_ci,
  `button` longtext COLLATE utf8mb4_unicode_ci,
  `text_position` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'start',
  `text_color` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_color` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_color` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indicator_color` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_fit` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'cover',
  `e_service_id` int(10) unsigned DEFAULT NULL,
  `e_provider_id` int(10) unsigned DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slides_e_service_id_foreign` (`e_service_id`),
  KEY `slides_e_provider_id_foreign` (`e_provider_id`),
  CONSTRAINT `slides_e_provider_id_foreign` FOREIGN KEY (`e_provider_id`) REFERENCES `e_providers` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `slides_e_service_id_foreign` FOREIGN KEY (`e_service_id`) REFERENCES `e_services` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slides`
--

LOCK TABLES `slides` WRITE;
/*!40000 ALTER TABLE `slides` DISABLE KEYS */;
INSERT INTO `slides` (`id`, `order`, `text`, `button`, `text_position`, `text_color`, `button_color`, `background_color`, `indicator_color`, `image_fit`, `e_service_id`, `e_provider_id`, `enabled`, `created_at`, `updated_at`) VALUES (1,1,'Assign a Handyman at Work to Fix the Household','Discover It','bottom_start','#333333','#009E6A','#FFFFFF','#333333','cover',NULL,NULL,1,'2021-01-25 06:21:45','2021-01-31 05:38:13'),(2,2,'Fix the Broken Stuff by Asking for the Technicians','Repair','bottom_start','#333333','#F4841F','#FFFFFF','#333333','cover',NULL,NULL,1,'2021-01-25 08:53:49','2021-01-31 05:33:05'),(3,3,'Add Hands to Your Cleaning Chores','Book Now','bottom_start','#333333','#1FA3F4','#FFFFFF','#333333','cover',NULL,NULL,1,'2021-01-31 05:34:36','2021-01-31 05:36:45');
/*!40000 ALTER TABLE `slides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxes`
--

DROP TABLE IF EXISTS `taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_ci,
  `value` double(10,2) NOT NULL DEFAULT '0.00',
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxes`
--

LOCK TABLES `taxes` WRITE;
/*!40000 ALTER TABLE `taxes` DISABLE KEYS */;
INSERT INTO `taxes` (`id`, `name`, `value`, `type`, `created_at`, `updated_at`) VALUES (1,'Tax 20',20.00,'percent','2021-01-15 05:42:13','2021-02-01 15:53:01'),(2,'Tax 10',10.00,'percent','2021-01-15 05:49:30','2021-01-15 05:49:30'),(3,'Maintenance',2.00,'fixed','2021-01-18 15:18:29','2021-02-01 15:55:13'),(4,'Tools Fee',5.00,'fixed','2021-02-01 15:54:12','2021-02-01 15:54:12');
/*!40000 ALTER TABLE `taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploads`
--

DROP TABLE IF EXISTS `uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploads`
--

LOCK TABLES `uploads` WRITE;
/*!40000 ALTER TABLE `uploads` DISABLE KEYS */;
INSERT INTO `uploads` (`id`, `uuid`, `created_at`, `updated_at`) VALUES (1,'66c92ec2-359a-4ec6-8803-a7212162af7d','2022-05-19 07:24:00','2022-05-19 07:24:00'),(2,'cc837abf-ebb6-429c-8df9-5a34b33d34b3','2022-05-19 08:10:11','2022-05-19 08:10:11');
/*!40000 ALTER TABLE `uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_token` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_brand` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_last_four` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `paypal_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_phone_number_unique` (`phone_number`),
  UNIQUE KEY `users_api_token_unique` (`api_token`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `phone_number`, `phone_verified_at`, `email_verified_at`, `password`, `api_token`, `device_token`, `stripe_id`, `card_brand`, `card_last_four`, `trial_ends_at`, `paypal_email`, `remember_token`, `created_at`, `updated_at`) VALUES (1,'Hyatt Zimmerman','admin@demo.com','+1 234 8996 321','2021-01-10 11:52:10','2021-01-10 11:52:10','$2y$10$YOn/Xq6vfvi9oaixrtW8QuM2W0mawkLLqIxL.IoGqrsqOqbIsfBNu','PivvPlsQWxPl1bB5KrbKNBuraJit0PrUZekQUgtLyTRuyBq921atFtoR1HuA','',NULL,NULL,NULL,NULL,NULL,'fU74kiNeDsPSli77nLRFboCEmUOuK57tpt9SGSczqnmlebqgOODfO8HXjYrb',NULL,'2021-02-09 11:20:32'),(2,'Jennifer Paul','provider@demo.com','+1 234 8996 322','2021-01-10 11:52:10','2021-01-10 11:52:10','$2y$10$YOn/Xq6vfvi9oaixrtW8QuM2W0mawkLLqIxL.IoGqrsqOqbIsfBNu','tVSfIKRSX2Yn8iAMoUS3HPls84ycS8NAxO2dj2HvePbbr4WHorp4gIFRmFwB','fPWbSFeNR3mo9ya2ryHuZV:APA91bFTEQFfkzek6GoEkinv6-wiNi6X-Gkj35sGTc4lkaFpoprMXtqA5eor6bNlrVU8UMdSf5ZTQsk9G4EhSz_zt0zKsWVXN70UZxXjTf_odPMNzlE2qQrb2Ok9iPOdoBVMBu8gXxJQ',NULL,NULL,NULL,NULL,NULL,'TwyKlf5NJ0oG6l5FfFhbCKsdRWrjF6HCunV8nZn2U9OXhJJTZ2Jxx4EqAJPA',NULL,'2022-05-18 09:13:20'),(3,'Germaine Guzman','customer@demo.com','+1 234 8996 323','2021-01-10 11:52:10','2021-01-10 11:52:10','$2y$10$EBubVy3wDbqNbHvMQwkj3OTYVitL8QnHvh/zV0ICVOaSbALy5dD0K','fXLu7VeYgXDu82SkMxlLPG1mCAXc4EBIx6O5isgYVIKFQiHah0xiOHmzNsBv','',NULL,NULL,NULL,NULL,NULL,'SPz6luq3aoxCbgIS1gqmFDgM1qzGlIDtF0HgmDbtWcx2reaeFcogcFQzdP2F',NULL,'2021-02-24 16:22:57'),(4,'Aimee Mcgee','provider1@demo.com','+1 234 8996 324','2021-01-10 11:52:10','2021-01-10 11:52:10','$2y$10$pmdnepS1FhZUMqOaFIFnNO0spltJpziz3j13UqyEwShmLhokmuoei','Czrsk9rwD0c75NUPkzNXM2WvbxYHKj8p0nG29pjKT0PZaTgMVzuVyv4hOlte','',NULL,NULL,NULL,NULL,NULL,'yCzPqDP1oczySU57q6G71SxTIJSiZUBE4vYdXbXCqzpzC2iN09igcs3jzSQK',NULL,'2021-02-21 09:20:29'),(5,'Josephine Harding','customer3@demo.com',NULL,NULL,NULL,'$2y$10$n/06hZG121ZGp3tSwDQS3uhsQKxEYspjKrn7kGlLxRinUZKiulrEm','gkEWScQHIol9EIRhP3m5m7JqnK5UvcGdEsKQJo7YeBcQawYFq3JAJ6SX9UKy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-01-11 05:25:52','2021-02-02 05:59:47'),(6,'Nicolette Christiansen','provider2@demo.com',NULL,NULL,'2021-01-10 18:30:00','$2y$04$WRpHC9iMxZ3f.gctQ4igsuZjsYfGjX7igVM8GsC2AMME3.4au3dYu','TKArYDDFHNiEI33sfExaBEhxHCs5kFaWP7EO6aNlUZfnqHrvsMCwsYeAk9s2',NULL,NULL,NULL,NULL,NULL,NULL,'JbiYaHlRWGKkfITxH9qI87GzTMPf0zJ2Iw6NIdlS5dDvWuT5PC2sP5ELGwKx','2021-01-11 06:03:59','2021-02-02 06:00:56'),(7,'Rose Bauer','customer2@demo.com',NULL,NULL,NULL,'$2y$10$3GhoIShzRdSXevYAh1NF/.67J3OshX9D2.sqY50o8kxh7EXPw7tuC','w6QJYqZyllY24AIR3nSsKqgj5eMSZevmgpSywwxJxUS9nwULcuriRLBxEXZC','',NULL,NULL,NULL,NULL,NULL,'WxYP9zjTBy9SYF5OWjcFbMt2Ob9r0bahBKzPDOtw9OrAJ89JqaMxkN5aqu8J','2021-01-17 10:43:24','2021-02-28 12:33:25'),(8,'smarter8','smartersvision@gmail.com','+12645595482',NULL,NULL,'$2y$10$MqPMTfg6RUNxxEH6aLdqnOYZUBsT7xtxkglD74pDgThV52.HJrLba','WivbG2oAEbEGl51EBeBuHaZeCqyfBnCVGo18nSaj2FwwiDjux2ZOAZWUoddK','',NULL,NULL,NULL,NULL,NULL,'SdstZCaeYW0pjqZn832HMzBD7WPGJ5m9hwWG28nhbIrzSS0etj33rbTRJ6kD','2021-02-10 06:01:12','2021-02-23 15:11:50'),(9,'himanshu','himanshu777000@gmail.com','+919096195966','2022-05-18 11:41:01',NULL,'$2y$10$kSWeC1iorcgVYG5qNf9ndOITAg1.99uD8OCnUpggr8vo9Ze5x5d3m','xlJvkidTWh3GEzBZcXdZdAgKrq2gpcfJwvlp4SporiV8ZIMq54gVH6RVaInp','fPWbSFeNR3mo9ya2ryHuZV:APA91bFTEQFfkzek6GoEkinv6-wiNi6X-Gkj35sGTc4lkaFpoprMXtqA5eor6bNlrVU8UMdSf5ZTQsk9G4EhSz_zt0zKsWVXN70UZxXjTf_odPMNzlE2qQrb2Ok9iPOdoBVMBu8gXxJQ',NULL,NULL,NULL,NULL,NULL,NULL,'2022-05-18 09:11:03','2022-05-18 09:11:03'),(10,'himanshu','himanshu.solicitous@gmail.com','+917798925200','2022-05-18 11:41:58',NULL,'$2y$10$2XMKfZnP/gdSwJOhUFvVTOiX.RGTnzVhBibcjRUh5I9G1WhMWkpou','0ye7Emp42CdG6OvtVO2RCWwPyHImM6vtGcxEfIcp5i0e8NUY6Elq7P8UfRQQ','fPWbSFeNR3mo9ya2ryHuZV:APA91bFTEQFfkzek6GoEkinv6-wiNi6X-Gkj35sGTc4lkaFpoprMXtqA5eor6bNlrVU8UMdSf5ZTQsk9G4EhSz_zt0zKsWVXN70UZxXjTf_odPMNzlE2qQrb2Ok9iPOdoBVMBu8gXxJQ',NULL,NULL,NULL,NULL,NULL,NULL,'2022-05-18 09:11:59','2022-05-18 09:11:59'),(11,'kavita jagtap','kavitagraphic@gmail.com','+918380948134','2022-05-19 09:02:39',NULL,'$2y$10$S9WQ9iFi/QuiKSBU9Gm.D.nI9NlTuE8EaDbBoSC04mFhdzTKfowgS','JnxyxRIdqPivukKXxj1jScf7la5FWmsL8e7LePxmDO6G2t7tKSJEvo4DcFdG','dwDsdBsLSBauhK6lPHlH-k:APA91bHLxVp4Kv1QssptIxKYkUmtlsr-ACf0zBL_afglBhAhpcO5LPsQ1x8nKy-NPG0fbqM82Kl-luQ887RPWI4njNlvXWYscSZBxVyoLl4rxF1oaE9ttrE_x31iodbYIQg5-96DalNa',NULL,NULL,NULL,NULL,NULL,NULL,'2022-05-19 06:32:42','2022-05-19 06:32:42');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallet_transactions`
--

DROP TABLE IF EXISTS `wallet_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wallet_transactions` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(10,2) NOT NULL DEFAULT '0.00',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` enum('credit','debit') COLLATE utf8mb4_unicode_ci NOT NULL,
  `wallet_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallet_transactions_wallet_id_foreign` (`wallet_id`),
  KEY `wallet_transactions_user_id_foreign` (`user_id`),
  CONSTRAINT `wallet_transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `wallet_transactions_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet_transactions`
--

LOCK TABLES `wallet_transactions` WRITE;
/*!40000 ALTER TABLE `wallet_transactions` DISABLE KEYS */;
INSERT INTO `wallet_transactions` (`id`, `amount`, `description`, `action`, `wallet_id`, `user_id`, `created_at`, `updated_at`) VALUES ('01194a4f-f302-47af-80b2-ceb2075d36dc',200.00,'First Transaction','credit','01194a4f-f302-47af-80b2-ceb2075d36dc',1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('02194a4f-f302-47af-80b2-ceb2075d36dc',200.00,'First Transaction','credit','02194a4f-f302-47af-80b2-ceb2075d36dc',1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('03194a4f-f302-47af-80b2-ceb2075d36dc',200.00,'First Transaction','credit','03194a4f-f302-47af-80b2-ceb2075d36dc',1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('04194a4f-f302-47af-80b2-ceb2075d36dc',200.00,'First Transaction','credit','04194a4f-f302-47af-80b2-ceb2075d36dc',1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('05194a4f-f302-47af-80b2-ceb2075d36dc',200.00,'First Transaction','credit','05194a4f-f302-47af-80b2-ceb2075d36dc',1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('06194a4f-f302-47af-80b2-ceb2075d36dc',200.00,'First Transaction','credit','06194a4f-f302-47af-80b2-ceb2075d36dc',1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('07194a4f-f302-47af-80b2-ceb2075d36dc',200.00,'First Transaction','credit','07194a4f-f302-47af-80b2-ceb2075d36dc',1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('8d194a4f-f302-47af-80b2-ceb2075d36dc',200.00,'First Transaction','credit','8d194a4f-f302-47af-80b2-ceb2075d36dc',1,'2021-08-07 07:47:34','2021-08-07 07:47:34');
/*!40000 ALTER TABLE `wallet_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallets`
--

DROP TABLE IF EXISTS `wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wallets` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` double(16,2) NOT NULL DEFAULT '0.00',
  `currency` longtext COLLATE utf8mb4_unicode_ci,
  `user_id` bigint(20) unsigned NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallets_user_id_foreign` (`user_id`),
  CONSTRAINT `wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallets`
--

LOCK TABLES `wallets` WRITE;
/*!40000 ALTER TABLE `wallets` DISABLE KEYS */;
INSERT INTO `wallets` (`id`, `name`, `balance`, `currency`, `user_id`, `enabled`, `created_at`, `updated_at`) VALUES ('01194a4f-f302-47af-80b2-ceb2075d36dc','My USD Wallet',200.00,'{\"id\":1,\"name\":\"US Dollar\",\"symbol\":\"$\",\"code\":\"USD\",\"decimal_digits\":2,\"rounding\":0}',1,1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('02194a4f-f302-47af-80b2-ceb2075d36dc','Home USD Wallet',200.00,'{\"id\":1,\"name\":\"US Dollar\",\"symbol\":\"$\",\"code\":\"USD\",\"decimal_digits\":2,\"rounding\":0}',2,1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('03194a4f-f302-47af-80b2-ceb2075d36dc','Work USD Wallet',200.00,'{\"id\":1,\"name\":\"US Dollar\",\"symbol\":\"$\",\"code\":\"USD\",\"decimal_digits\":2,\"rounding\":0}',3,1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('04194a4f-f302-47af-80b2-ceb2075d36dc','Dummy USD Wallet',200.00,'{\"id\":1,\"name\":\"US Dollar\",\"symbol\":\"$\",\"code\":\"USD\",\"decimal_digits\":2,\"rounding\":0}',4,1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('05194a4f-f302-47af-80b2-ceb2075d36dc','Old USD Wallet',200.00,'{\"id\":1,\"name\":\"US Dollar\",\"symbol\":\"$\",\"code\":\"USD\",\"decimal_digits\":2,\"rounding\":0}',5,1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('06194a4f-f302-47af-80b2-ceb2075d36dc','New USD Wallet',200.00,'{\"id\":1,\"name\":\"US Dollar\",\"symbol\":\"$\",\"code\":\"USD\",\"decimal_digits\":2,\"rounding\":0}',6,1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('07194a4f-f302-47af-80b2-ceb2075d36dc','USD Wallet',200.00,'{\"id\":1,\"name\":\"US Dollar\",\"symbol\":\"$\",\"code\":\"USD\",\"decimal_digits\":2,\"rounding\":0}',7,1,'2021-08-07 07:47:34','2021-08-07 07:47:34'),('8d194a4f-f302-47af-80b2-ceb2075d36dc','Dollar Wallet',200.00,'{\"id\":1,\"name\":\"US Dollar\",\"symbol\":\"$\",\"code\":\"USD\",\"decimal_digits\":2,\"rounding\":0}',8,1,'2021-01-07 07:47:34','2021-01-07 07:47:34');
/*!40000 ALTER TABLE `wallets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'solicitous_h2o'
--

--
-- Dumping routines for database 'solicitous_h2o'
--
/*!50003 DROP FUNCTION IF EXISTS `json_extract` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`solicitous_h2o`@`localhost` FUNCTION `json_extract`(
        details TEXT,
        required_field VARCHAR (255)
        ) RETURNS text CHARSET latin1
BEGIN
        SET details = SUBSTRING_INDEX(details, "{", -1);
        SET details = SUBSTRING_INDEX(details, "}", 1);
        RETURN TRIM(
            BOTH '"' FROM SUBSTRING_INDEX(
                SUBSTRING_INDEX(
                    SUBSTRING_INDEX(
                        details,
                        CONCAT(
                            '"',
                            SUBSTRING_INDEX(required_field,'$.', -1),
                            '":'
                        ),
                        -1
                    ),
                    ',"',
                    1
                ),
                ':',
                -1
            )
        ) ;
        END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-20 12:11:37
